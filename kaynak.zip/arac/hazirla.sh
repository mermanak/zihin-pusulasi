#!/usr/bin/env bash
# Flutter projesini _app klasöründe kurar: kod, soru paketi, simgeler, Android ve web ayarları.
set -euo pipefail

flutter create --org com.ermanak --project-name bilsem_hazirlik --platforms android,web _app
rm -rf _app/lib _app/test
cp -r lib _app/lib
cp pubspec.yaml _app/pubspec.yaml
for z in paket*.zip; do echo "açılıyor: $z"; unzip -q -o "$z" -d _app; done

python3 - <<'EOF'
import os, re

# Android: uygulama adı, izinler, ayrı uygulama kimliği (deneme sürümü)
p = '_app/android/app/src/main/AndroidManifest.xml'
x = open(p, encoding='utf-8').read()
x = re.sub(r'android:label="[^"]*"', 'android:label="Zihin Pusulası"', x)
if 'android.permission.INTERNET' not in x:
    x = x.replace('<application', '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
extra = ''
if 'TTS_SERVICE' not in x:
    extra += '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'
if 'mailto' not in x:
    extra += '<intent><action android:name="android.intent.action.SENDTO"/><data android:scheme="mailto"/></intent>'
    extra += '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>'
if extra:
    if '<queries>' in x:
        x = x.replace('<queries>', '<queries>\n        ' + extra, 1)
    else:
        x = x.replace('</manifest>', '    <queries>' + extra + '</queries>\n</manifest>')
open(p, 'w', encoding='utf-8').write(x)

for g in ('_app/android/app/build.gradle.kts', '_app/android/app/build.gradle'):
    if os.path.exists(g):
        y = open(g, encoding='utf-8').read()
        y2 = re.sub(r'(applicationId\s*=?\s*)"[^"]*"', r'\1"com.ermanak.zihinpusulasi.deneme"', y, count=1)
        assert y2 != y, 'applicationId bulunamadı: ' + g
        open(g, 'w', encoding='utf-8').write(y2)
        print(g, '-> com.ermanak.zihinpusulasi.deneme')

# Soru görselleri klasör klasör pubspec'e eklenir
p = '_app/pubspec.yaml'
x = open(p, encoding='utf-8').read()
root = '_app/assets/gorsel'
dirs = sorted(d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d)))
lines = ['    - assets/bilsem-sorular.json'] + ['    - assets/gorsel/%s/' % d for d in dirs]
x = re.sub(r'(?m)^  assets:\n(?:    - .*\n?)*', '  assets:\n' + '\n'.join(lines) + '\n', x)
open(p, 'w', encoding='utf-8').write(x)
print(len(dirs), 'görsel klasörü pubspec dosyasına eklendi')
EOF

python3 arac/web_yama.py _app/web
