"""Yayın sitesini _site klasöründe toplar: açılış sayfası kökte, uygulama uygulama/ altında.

Kullanım: python3 arac/site.py <flutter web çıktısı> <hedef>
GITHUB_REPOSITORY ortam değişkeninden (sahip/depo) adres ve APK bağlantısı yazılır.
"""
import os
import shutil
import sys

web, hedef = sys.argv[1], sys.argv[2]
repo = os.environ['GITHUB_REPOSITORY']
sahip, ad = repo.split('/')
site_adresi = 'https://%s.github.io/%s/' % (sahip.lower(), ad)

if os.path.exists(hedef):
    shutil.rmtree(hedef)
shutil.copytree('site', hedef)
shutil.copytree(web, os.path.join(hedef, 'uygulama'))

p = os.path.join(hedef, 'index.html')
x = open(p, encoding='utf-8').read()
x = x.replace('__SITE__', site_adresi).replace('__REPO__', repo)
assert '__' not in x.replace('__proto__', ''), 'doldurulmamış alan kaldı'
open(p, 'w', encoding='utf-8').write(x)

# Jekyll kapalı: alt çizgiyle başlayan klasörler de yayınlansın
open(os.path.join(hedef, '.nojekyll'), 'w').close()
print('site hazır:', site_adresi)
