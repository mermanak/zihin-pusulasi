"""flutter create ile oluşan web dosyalarını Zihin Pusulası'na göre düzenler.

- index.html: Türkçe başlık ve açıklama, ana ekran adı ve simgesi, açılış ekranı,
  iPhone/Android için "ana ekrana ekleyin" bandı, Instagram/X tarayıcısı uyarısı
- manifest.json: ad, renkler, simgeler
Kullanım: python3 arac/web_yama.py _app/web
"""
import json
import os
import re
import sys

web = sys.argv[1]
AD = 'Zihin Pusulası'
ACIKLAMA = "İlkokul 1-4. sınıf için dikkat, hafıza ve BİLSEM'e hazırlık çalışmaları. Deneme sürümü."

p = os.path.join(web, 'index.html')
x = open(p, encoding='utf-8').read()
x = re.sub(r'<html[^>]*>', '<html lang="tr">', x, count=1)
x = re.sub(r'<title>.*?</title>', '<title>%s</title>' % AD, x, count=1, flags=re.S)
x = re.sub(r'<meta name="description"[^>]*>', '<meta name="description" content="%s">' % ACIKLAMA, x, count=1)
x = re.sub(r'<meta name="apple-mobile-web-app-title"[^>]*>', '<meta name="apple-mobile-web-app-title" content="%s">' % AD, x, count=1)
x = re.sub(r'<meta name="apple-mobile-web-app-status-bar-style"[^>]*>',
           '<meta name="apple-mobile-web-app-status-bar-style" content="default">', x, count=1)
x = re.sub(r'<link rel="apple-touch-icon"[^>]*>', '<link rel="apple-touch-icon" href="apple-touch-icon.png">', x, count=1)
if 'apple-mobile-web-app-capable' not in x:
    x = x.replace('</head>', '  <meta name="apple-mobile-web-app-capable" content="yes">\n</head>', 1)
if 'theme-color' not in x:
    x = x.replace('</head>', '  <meta name="theme-color" content="#1C2669">\n</head>', 1)

STIL = """
  <style>
    html,body{margin:0;height:100%;background:#F4F6FB}
    #zp-acilis{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;
      gap:14px;background:#F4F6FB;font:500 15px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#5B6585;z-index:5}
    #zp-acilis img{width:96px;height:96px;border-radius:24px;box-shadow:0 8px 24px rgba(24,33,63,.18)}
    #zp-acilis b{font-size:20px;color:#18213F}
    #zp-bant{position:fixed;left:10px;right:10px;bottom:calc(10px + env(safe-area-inset-bottom));z-index:10;display:none;
      background:#18213F;color:#fff;border-radius:16px;padding:12px 44px 12px 14px;box-shadow:0 8px 28px rgba(0,0,0,.28);
      font:400 14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
    #zp-bant b{color:#FFD872;font-weight:600}
    #zp-bant button{position:absolute;right:6px;top:6px;width:32px;height:32px;border:0;border-radius:50%;
      background:rgba(255,255,255,.12);color:#fff;font-size:18px;line-height:32px;cursor:pointer}
  </style>
"""
x = x.replace('</head>', STIL + '</head>', 1)

GOVDE = """
  <div id="zp-acilis"><img src="apple-touch-icon.png" alt=""><b>Zihin Pusulası</b><span>Yükleniyor…</span></div>
  <div id="zp-bant" role="note"><span id="zp-bant-metin"></span><button type="button" aria-label="Kapat">×</button></div>
  <script>
    (function () {
      window.addEventListener('flutter-first-frame', function () {
        var a = document.getElementById('zp-acilis');
        if (a) a.remove();
      });
      var ua = navigator.userAgent || '';
      var ios = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
      var android = /Android/.test(ua);
      var inApp = /Instagram|FBAN|FBAV|FB_IAB|Twitter|LinkedInApp|Line\\/|Snapchat|TikTok|musical_ly|BytedanceWebview/i.test(ua);
      var standalone = window.navigator.standalone === true ||
        (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
      var metin = '';
      if (inApp) {
        metin = 'Bu sayfa uygulamanın kendi tarayıcısında açıldı. İlerlemenin kaybolmaması için sağ üstteki <b>•••</b> menüsünden <b>Tarayıcıda aç</b> (iPhone\\'da <b>Safari\\'de aç</b>) seçeneğine dokunun.';
      } else if (ios && !standalone) {
        metin = 'Ana ekrana ekleyin: <b>Paylaş</b> düğmesine (görünmüyorsa önce <b>•••</b> simgesine), sonra <b>Ana Ekrana Ekle</b>\\'ye dokunun. Çocuğunuzun ilerlemesi orada saklanır.';
      } else if (android && !standalone) {
        metin = 'Ana ekrana ekleyin: sağ üstteki <b>⋮</b> menüsünden <b>Ana ekrana ekle</b>\\'yi seçin. Çocuğunuzun ilerlemesi orada saklanır.';
      }
      var kapali = false;
      try { kapali = sessionStorage.getItem('zp-bant') === 'kapali'; } catch (e) {}
      if (metin && !kapali) {
        var b = document.getElementById('zp-bant');
        document.getElementById('zp-bant-metin').innerHTML = metin;
        b.style.display = 'block';
        b.querySelector('button').onclick = function () {
          b.remove();
          try { sessionStorage.setItem('zp-bant', 'kapali'); } catch (e) {}
        };
      }
    })();
  </script>
"""
x = re.sub(r'<body[^>]*>', lambda m: m.group(0) + GOVDE, x, count=1)
open(p, 'w', encoding='utf-8').write(x)
print(x)

m = os.path.join(web, 'manifest.json')
man = {
    'name': AD,
    'short_name': AD,
    'description': ACIKLAMA,
    'lang': 'tr',
    'start_url': '.',
    'scope': '.',
    'display': 'standalone',
    'orientation': 'portrait-primary',
    'background_color': '#F4F6FB',
    'theme_color': '#1C2669',
    'prefer_related_applications': False,
    'icons': [
        {'src': 'icons/Icon-192.png', 'sizes': '192x192', 'type': 'image/png'},
        {'src': 'icons/Icon-512.png', 'sizes': '512x512', 'type': 'image/png'},
        {'src': 'icons/Icon-maskable-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'maskable'},
        {'src': 'icons/Icon-maskable-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'},
    ],
}
json.dump(man, open(m, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('manifest.json yazıldı')
