import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Opt {
  final String id;
  final String? text;
  final String? image;
  Opt(this.id, this.text, this.image);
  factory Opt.fromJson(Map<String, dynamic> j) => Opt(j['id'] as String, j['text'] as String?, j['image'] as String?);
}

class Question {
  final String id;
  final int grade;
  final String topic;
  final String subtopic;
  final String stem;
  final String? image;
  final List<Opt> options;
  final String answer;
  final String explanation;
  final String? hint;
  final String mode;
  final String konu;
  final String? beceri;
  final String? veliNotu;

  /// Deneme sürümündeki sırası (1-12); deneme sürümünde gösterilmeyen sorularda yoktur.
  final int? demoSira;

  Question({
    required this.id,
    required this.grade,
    required this.topic,
    required this.subtopic,
    required this.stem,
    required this.image,
    required this.options,
    required this.answer,
    required this.explanation,
    required this.hint,
    required this.mode,
    required this.konu,
    this.beceri,
    this.veliNotu,
    this.demoSira,
  });

  bool get isPractice => mode == 'alistirma';
  bool get hasImageOptions => options.isNotEmpty && options.first.image != null;
  Opt optionById(String id) => options.firstWhere((o) => o.id == id);

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id'] as String,
        grade: (j['grade'] as List).first as int,
        topic: j['topic'] as String,
        subtopic: j['subtopic'] as String,
        stem: j['stem'] as String,
        image: j['image'] as String?,
        options: (j['options'] as List).map((e) => Opt.fromJson(e as Map<String, dynamic>)).toList(),
        answer: j['answer'] as String,
        explanation: j['explanation'] as String,
        hint: j['hint'] as String?,
        mode: (j['mode'] as String?) ?? 'test',
        konu: (j['konu_grubu'] as String?) ?? 'sozel',
        beceri: j['beceri'] as String?,
        veliNotu: j['veli_notu'] as String?,
        demoSira: j['demo_sira'] as int?,
      );

  /// Sesli okuma için metin.
  String get speech {
    final b = StringBuffer(stem);
    if (!hasImageOptions) {
      for (final o in options) {
        b.write('. ${o.id}: ${o.text}');
      }
    }
    return b.toString();
  }
}

class TestResult {
  final int grade;
  final String konu;
  final int stage;
  final int total;
  final int correct;
  final Map<String, String> answers; // soru id -> seçilen şık
  final List<String> wrongIds;
  final DateTime at;

  TestResult({
    required this.grade,
    required this.konu,
    required this.stage,
    required this.total,
    required this.correct,
    required this.answers,
    required this.wrongIds,
    required this.at,
  });

  Map<String, dynamic> toJson() => {
        'grade': grade,
        'konu': konu,
        'stage': stage,
        'total': total,
        'correct': correct,
        'answers': answers,
        'wrong': wrongIds,
        'at': at.toIso8601String(),
      };

  factory TestResult.fromJson(Map<String, dynamic> j) => TestResult(
        grade: j['grade'] as int,
        konu: j['konu'] as String,
        stage: j['stage'] as int,
        total: j['total'] as int,
        correct: j['correct'] as int,
        answers: Map<String, String>.from(j['answers'] as Map),
        wrongIds: List<String>.from(j['wrong'] as List),
        at: DateTime.parse(j['at'] as String),
      );

  int get stars {
    final r = total == 0 ? 0.0 : correct / total;
    if (r >= 0.9) return 3;
    if (r >= 0.7) return 2;
    return 1;
  }
}

const securityQuestions = [
  'İlk evcil hayvanınızın adı neydi?',
  'Doğduğunuz şehir neresi?',
  'İlkokul öğretmeninizin adı neydi?',
];

const subtopicNames = {
  'matris-latin': 'Matris: her satırda üç çeşidin birer kez geçtiği sorular',
  'matris-satir-sutun': 'Matris: satır ve sütun kuralları',
  'matris-sayi': 'Matris: şekil sayısı kuralları',
  'matris-konum': 'Matris: köşe değiştiren şekiller',
  'matris-birlestirme': 'Matris: kutuları üst üste koyma',
  'gorsel-analoji': 'Görsel: şekil analojileri',
  'sayma-dikkat': 'Görsel: sayma ve dikkat',
  'deyim': 'Sözel: deyimler',
  'es-anlam': 'Sözel: eş anlamlı sözcükler',
  'zit-anlam': 'Sözel: zıt anlamlı sözcükler',
  'analoji': 'Sözel: ilişki kurma (analoji)',
  'sayi-oruntusu': 'Sözel: sayı örüntüleri',
  'sira-muhakemesi': 'Sözel: sıralama muhakemesi',
  'mantik-siralama': 'Sözel: mantıksal sıralama',
  'kesin-sonuc': 'Sözel: kesin sonuç çıkarma',
  'problem': 'Sözel: problemler',
  'takvim': 'Sözel: gün ve aylar',
  'farkli-olani-bul': 'Farklı olanı bulma',
  'metin-anlama': 'Sözel: okuduğunu anlama',
  'kategori': 'Sözel: gruplama',
  'akrabalik': 'Sözel: akrabalık ilişkileri',
  'mecaz-anlam': 'Sözel: mecaz anlam',
  'iliski-analoji': 'Sözel: ilişki benzerliği',
  'derece-analoji': 'Sözel: derece ilişkisi',
  'olay-siralama': 'Sözel: olayları sıralama',
  'oturma-duzeni': 'Sözel: oturma düzeni',
  'yon': 'Sözel: yön bulma',
  'saat': 'Sözel: saat ve süre',
  'yas-problemi': 'Sözel: yaş problemleri',
  'terazi': 'Sözel: terazi ve denklik',
  'sayma': 'Sözel: rakam ve sayı sayma',
  'mantik': 'Sözel: mantık bulmacaları',
  'kumeler': 'Sözel: kümeler',
  'sozcuk-oyunu': 'Sözel: sözcük oyunları',
  'sifre': 'Sözel: şifre çözme',
  'matris-yon': 'Matris: ok yönü (dönme) kuralları',
  'matris-ic-ice': 'Matris: iç içe şekiller',
  'sekil-dizisi': 'Görsel: şekil dizileri',
  'dondurme': 'Görsel: şekli döndürme',
  'ayna-goruntusu': 'Görsel: ayna görüntüsü',
  'desen-tamamlama': 'Görsel: simetrik desen tamamlama',
  'ters-cevrilmis': 'Görsel: ters çevrilmiş şekli bulma',
  'sekil-sayma': 'Görsel: iç içe şekil sayma',
  'kagit-katlama': 'Görsel: kâğıt katlama',
  'yonerge-takibi': 'Sözel: yönerge takibi',
  'sekil-denklemi': 'Sözel: şekil denklemleri',
  'kod-cozme': 'Sözel: kod çözme',
  'sayi-bulmacasi': 'Sözel: sayı bulmacaları',
};

/// Uygulamanın adı ve alt başlığı.
const appName = 'Zihin Pusulası';
const appTagline = 'Dikkat · Hafıza · Zekâ · BİLSEM\'e hazırlık';

/// Uygulama sürümü (geri bildirim e-postasına eklenir).
const appVersion = '1.2.0';

/// Geliştirici iletişim bilgileri (ebeveyn panelindeki geri bildirim bölümü).
const devName = 'Mustafa Erman Akçakmak';
const devTitle = 'Uzman Psikolojik Danışman';
const devMail = 'ermanak87@hotmail.com';
const devInstagram = 'mermanak';
const devTwitter = 'mermanak';

/// Uygulamanın desteklediği sınıflar.
const grades = [1, 2, 3, 4];

int _clampInt(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

String subtopicName(String s) => subtopicNames[s] ?? s.replaceAll('-', ' ');

String _norm(String s) => s.trim().replaceAll('I', 'ı').replaceAll('İ', 'i').toLowerCase();
String _hash(String s) => sha256.convert(utf8.encode('bilsem-hazirlik:$s')).toString();

/// Uygulamanın tüm durumu: sorular, ayarlar ve ilerleme (yalnızca bu cihazda saklanır).
class AppState {
  AppState._();
  static final AppState instance = AppState._();

  late SharedPreferences _p;
  List<Question> all = [];
  final Map<String, Question> _byId = {};
  static const fullStageSize = 8;

  /// Deneme sürümü: her bölümde yalnızca demo_sira taşıyan sorular, 6'şar soruluk duraklarla gösterilir.
  /// Tam sürüme geçmek için soru dosyasında meta.demo.aktif false yapılır; hiçbir soru silinmez.
  bool demo = false;
  int _demoStageSize = 6;
  Map<String, int> _fullCounts = {};
  int get stageSize => demo ? _demoStageSize : fullStageSize;

  /// Ebeveyn başka durak açmadıkça her bölümde açık olan durak sayısı.
  static const defaultUnlocked = 2;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final raw = await rootBundle.loadString('assets/bilsem-sorular.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    all = (j['questions'] as List).map((e) => Question.fromJson(e as Map<String, dynamic>)).toList();
    _byId
      ..clear()
      ..addEntries(all.map((q) => MapEntry(q.id, q)));
    // Soru seti yenilendiğinde eski ilerleme yeni sorularla karışmasın: sonuçlar ve duraklar sıfırlanır,
    // kurulum bilgileri (sınıf, ad, şifre, güvenlik sorusu) korunur.
    final meta = j['meta'] as Map<String, dynamic>?;
    final dm = meta?['demo'] as Map<String, dynamic>?;
    demo = (dm?['aktif'] as bool?) ?? false;
    _demoStageSize = (dm?['durak_soru'] as int?) ?? 6;
    // Herkese açık deneme paketinde gizli sorular yoktur; tam sürümdeki sayılar buradan okunur.
    final tc = dm?['tam_sayilar'] as Map<String, dynamic>?;
    _fullCounts = tc == null ? {} : tc.map((k, v) => MapEntry(k, (v as num).toInt()));
    final version = (meta?['version'] as int?) ?? 0;
    if (_p.getInt('dataVersion') != version) {
      for (final k in _p.getKeys().toList()) {
        if (k.startsWith('done_') || k.startsWith('stars_') || k == 'results') await _p.remove(k);
      }
      await _p.setInt('dataVersion', version);
    }
    if (!grades.contains(grade)) await setGrade(1);
  }

  // ---------------------------------------------------------- ayarlar
  bool get setupDone => _p.getBool('setupDone') ?? false;
  Future<void> finishSetup() => _p.setBool('setupDone', true);

  int get grade => _p.getInt('grade') ?? 1;
  Future<void> setGrade(int g) => _p.setInt('grade', g);

  String get childName => _p.getString('childName') ?? '';
  Future<void> setChildName(String n) => _p.setString('childName', n.trim());

  bool get ttsOn => _p.getBool('tts') ?? true;
  Future<void> setTts(bool v) => _p.setBool('tts', v);

  Future<void> setPin(String pin) => _p.setString('pin', _hash(pin));
  bool checkPin(String pin) => _p.getString('pin') == _hash(pin);

  int get securityIndex => _p.getInt('secQ') ?? 0;
  Future<void> setSecurity(int index, String answer) async {
    await _p.setInt('secQ', index);
    await _p.setString('secA', _hash(_norm(answer)));
  }

  bool checkSecurity(String answer) => _p.getString('secA') == _hash(_norm(answer));

  // ---------------------------------------------------------- sorular ve bölümler
  List<Question> tests(String konu) {
    final list = all
        .where((q) => q.grade == grade && q.konu == konu && !q.isPractice && (!demo || q.demoSira != null))
        .toList();
    if (demo) {
      list.sort((a, b) => a.demoSira!.compareTo(b.demoSira!));
    } else {
      list.sort((a, b) => a.id.compareTo(b.id));
    }
    return list;
  }

  /// Tam sürümde bu bölümdeki test sorusu sayısı (deneme sürümünde gizli olanlar dahil).
  int fullTestCount(String konu) =>
      _fullCounts['${grade}_$konu'] ?? all.where((q) => q.grade == grade && q.konu == konu && !q.isPractice).length;

  /// Deneme sürümünde bölümün bütün durakları bitti mi?
  bool demoFinished(String konu) {
    if (!demo) return false;
    for (var i = 0; i < stageCount(konu); i++) {
      if (!stageDone(konu, i)) return false;
    }
    return true;
  }

  List<Question> practicePool(String konu) =>
      all.where((q) => q.grade == grade && q.konu == konu && q.isPractice).toList()..sort((a, b) => a.id.compareTo(b.id));

  int stageCount(String konu) => (tests(konu).length / stageSize).ceil();

  List<Question> stageTests(String konu, int stage) => tests(konu).skip(stage * stageSize).take(stageSize).toList();

  List<Question> stagePractice(String konu, int stage) {
    final p = practicePool(konu);
    if (p.isEmpty) return [];
    return [p[(2 * stage) % p.length], p[(2 * stage + 1) % p.length]];
  }

  Question byId(String id) => _byId[id]!;
  Question? byIdOrNull(String id) => _byId[id];

  // ---------------------------------------------------------- ebeveyn kilidi
  String _ul(String konu) => 'unl_${grade}_$konu';
  int unlockedCount(String konu) =>
      demo ? stageCount(konu) : _clampInt(_p.getInt(_ul(konu)) ?? defaultUnlocked, 1, stageCount(konu));
  bool isUnlocked(String konu, int stage) => stage < unlockedCount(konu);
  Future<void> unlockMore(String konu) => _p.setInt(_ul(konu), _clampInt(unlockedCount(konu) + 1, 1, stageCount(konu)));
  Future<void> unlockAll(String konu) => _p.setInt(_ul(konu), stageCount(konu));
  Future<void> resetLock(String konu) => _p.setInt(_ul(konu), defaultUnlocked);

  /// Çocuk açık durakların hepsini bitirdi ve sıradaki durak ebeveyn kilidinde mi?
  bool waitingForParent(String konu) {
    final u = unlockedCount(konu);
    if (u >= stageCount(konu)) return false;
    for (var i = 0; i < u; i++) {
      if (!stageDone(konu, i)) return false;
    }
    return true;
  }

  // ---------------------------------------------------------- beceri istatistiği
  /// beceri -> [doğru, toplam], seçili sınıfın test sonuçlarından.
  Map<String, List<int>> skillStats() {
    final m = <String, List<int>>{};
    for (final r in results.where((r) => r.grade == grade)) {
      r.answers.forEach((id, a) {
        final q = byIdOrNull(id);
        final b = q?.beceri;
        if (q == null || b == null) return;
        final e = m.putIfAbsent(b, () => [0, 0]);
        e[1] += 1;
        if (a == q.answer) e[0] += 1;
      });
    }
    return m;
  }

  /// Bir becerinin veli notu (o beceriyi taşıyan ilk sorudan).
  String? skillNote(String beceri) {
    for (final q in all) {
      if (q.beceri == beceri && q.veliNotu != null) return q.veliNotu;
    }
    return null;
  }

  // Deneme sürümünün durakları tam sürümünkilerle karışmasın diye ayrı anahtarla saklanır.
  String _k(String konu, int stage) => '${demo ? 'd' : ''}${grade}_${konu}_$stage';
  bool stageDone(String konu, int stage) => _p.getBool('done_${_k(konu, stage)}') ?? false;
  int stageStars(String konu, int stage) => _p.getInt('stars_${_k(konu, stage)}') ?? 0;

  /// Oynanabilir son durak (tamamlananların bir sonrası).
  int currentStage(String konu) {
    final n = stageCount(konu);
    for (var i = 0; i < n; i++) {
      if (!stageDone(konu, i)) return i;
    }
    return n - 1;
  }

  int solvedCount(String konu) {
    var s = 0;
    for (var i = 0; i < stageCount(konu); i++) {
      if (stageDone(konu, i)) s += stageTests(konu, i).length;
    }
    return s;
  }

  int get totalStars {
    var s = 0;
    for (final k in ['sozel', 'gorsel', 'matris']) {
      for (var i = 0; i < stageCount(k); i++) {
        s += stageStars(k, i);
      }
    }
    return s;
  }

  // ---------------------------------------------------------- günlük görev
  static const dailyGoal = 10;
  String get _today {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  int get todayCount => _p.getString('day') == _today ? (_p.getInt('dayCount') ?? 0) : 0;
  Future<void> addAnswered(int n) async {
    final c = todayCount + n;
    await _p.setString('day', _today);
    await _p.setInt('dayCount', c);
  }

  // ---------------------------------------------------------- sonuçlar
  List<TestResult> get results {
    final raw = _p.getString('results');
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => TestResult.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> saveResult(TestResult r) async {
    final list = results..add(r);
    await _p.setString('results', jsonEncode(list.map((e) => e.toJson()).toList()));
    final key = _k(r.konu, r.stage);
    await _p.setBool('done_$key', true);
    final best = _p.getInt('stars_$key') ?? 0;
    if (r.stars > best) await _p.setInt('stars_$key', r.stars);
  }
}

/// Soruları sesli okur (Türkçe).
class Speaker {
  static final FlutterTts _tts = FlutterTts();
  static bool _ready = false;

  static Future<void> say(String text) async {
    if (!AppState.instance.ttsOn) return;
    try {
      if (!_ready) {
        await _tts.setLanguage('tr-TR');
        // Tarayıcıda 1.0 normal hızdır; telefon uygulamasında 0.5 civarı normaldir.
        await _tts.setSpeechRate(kIsWeb ? 0.9 : 0.45);
        _ready = true;
      }
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {
      // Cihazda Türkçe ses yoksa sessizce geç.
    }
  }

  static Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
