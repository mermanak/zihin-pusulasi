import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'data.dart';
import 'screens/child_screens.dart';
import 'screens/setup_screens.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  } catch (_) {
    // Tarayıcıda ekran yönü kilitlenemeyebilir.
  }
  await AppState.instance.load();
  runApp(const BilsemApp());
}

class BilsemApp extends StatelessWidget {
  const BilsemApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: appName,
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: AppState.instance.setupDone ? const ChildHome() : const WelcomeScreen(),
      );
}
