import 'package:flutter/material.dart';

import '../data.dart';
import '../theme.dart';
import '../widgets.dart';
import 'parent_screens.dart';

AppState get _s => AppState.instance;

/// 4 · Çocuk ana ekranı.
class ChildHome extends StatefulWidget {
  const ChildHome({super.key});
  @override
  State<ChildHome> createState() => _ChildHomeState();
}

class _ChildHomeState extends State<ChildHome> {
  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final name = _s.childName;
    final today = _s.todayCount.clamp(0, AppState.dailyGoal).toInt();
    return Scaffold(
      backgroundColor: C.bg,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          GradientHeader(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 54),
            child: Column(children: [
              Row(children: [
                Pill('${_s.grade}. sınıf', bg: Colors.white.withAlpha(36), fg: Colors.white, size: 12.5),
                const Spacer(),
                StarPill(_s.totalStars),
                const SizedBox(width: 8),
                _ParentButton(onTap: () => _open(const ParentGate())),
              ]),
              const SizedBox(height: 14),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                const Owl(size: 88),
                const SizedBox(width: 10),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 18),
                    child: Bubble('Bugün hangi yolu deneyelim?', title: name.isEmpty ? 'Merhaba!' : 'Merhaba $name!'),
                  ),
                ),
              ]),
            ]),
          ),
          Transform.translate(
            offset: const Offset(0, -34),
            child: Frame(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: AppCard(
                  padding: const EdgeInsets.fromLTRB(14, 14, 16, 14),
                  child: Row(children: [
                    Ring(today / AppState.dailyGoal,
                        size: 54,
                        stroke: 6,
                        color: C.sun,
                        child: Text('$today/${AppState.dailyGoal}', style: tStrong(size: 12.5))),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Günün görevi', style: tStrong(size: 15)),
                        Text(
                            today >= AppState.dailyGoal
                                ? 'Bugünün görevini tamamladın, harikasın!'
                                : 'Bugün ${AppState.dailyGoal} soru çöz, yıldızını kap.',
                            style: tCaption()),
                      ]),
                    ),
                    if (today >= AppState.dailyGoal) const Icon(Icons.emoji_events_rounded, color: C.sun, size: 30),
                  ]),
                ),
              ),
            ),
          ),
          Frame(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                SectionTitle('Yollar', trailing: _s.demo ? const DemoBadge() : null),
                for (final k in konular) ...[
                  _KonuCard(konu: k, onTap: () => _open(TopicMap(konu: k))),
                  const SizedBox(height: 12),
                ],
                if (_s.demo)
                  InfoNote(
                      'Bu bir deneme sürümü: her yolda ${_s.tests('sozel').length} soru açık. '
                      'Tam sürümde her yolda ${_s.fullTestCount('sozel')} soru var.'),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _ParentButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ParentButton({required this.onTap});
  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        label: 'Ebeveyn bölümü',
        child: Material(
          color: Colors.white.withAlpha(36),
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Container(
              height: 36,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.lock_rounded, size: 16, color: Colors.white),
                const SizedBox(width: 6),
                Text('Ebeveyn', style: tLabel(color: Colors.white, size: 12.5)),
              ]),
            ),
          ),
        ),
      );
}

class _KonuCard extends StatelessWidget {
  final Konu konu;
  final VoidCallback onTap;
  const _KonuCard({required this.konu, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final total = _s.tests(konu.key).length;
    final solved = _s.solvedCount(konu.key);
    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      semanticLabel: '${konu.title} yolu, $solved / $total soru çözüldü',
      child: Row(children: [
        Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            color: konu.color,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [BoxShadow(color: konu.dark, offset: const Offset(0, 4))],
          ),
          child: Icon(konu.icon, color: Colors.white, size: 30),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(konu.title, style: tTitle(size: 17)),
            Text(konu.subtitle, style: tCaption()),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: ProgressLine(total == 0 ? 0.0 : solved / total, color: konu.color)),
              const SizedBox(width: 10),
              Text('$solved/$total', style: tStrong(color: konu.dark, size: 12.5)),
            ]),
          ]),
        ),
        const SizedBox(width: 6),
        const Icon(Icons.chevron_right_rounded, color: C.faint),
      ]),
    );
  }
}

/// 5 · Konu haritası (duraklar).
class TopicMap extends StatefulWidget {
  final Konu konu;
  const TopicMap({super.key, required this.konu});
  @override
  State<TopicMap> createState() => _TopicMapState();
}

class _TopicMapState extends State<TopicMap> {
  Future<void> _play(int stage) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => StageIntro(konu: widget.konu, stage: stage)));
    if (mounted) setState(() {});
  }

  Widget _owlCard(String title, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: AppCard(
          child: Row(children: [
            const Owl(size: 60, mood: OwlMood.happy),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: tStrong(size: 15)),
                const SizedBox(height: 2),
                Text(text, style: tCaption()),
              ]),
            ),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final k = widget.konu;
    final n = _s.stageCount(k.key);
    final cur = _s.currentStage(k.key);
    final unl = _s.unlockedCount(k.key);
    final total = _s.tests(k.key).length;
    final solved = _s.solvedCount(k.key);
    final extra = _s.fullTestCount(k.key) - total;
    final extraStages = (_s.fullTestCount(k.key) / AppState.fullStageSize).ceil() - n;
    final nodes = <Widget>[];
    if (_s.demoFinished(k.key)) {
      nodes.add(_owlCard('Deneme sorularının hepsini bitirdin!',
          'Bu yolda $extra soru daha var. Ailen tam sürümü açınca devam edersin.'));
    }
    if (_s.waitingForParent(k.key)) {
      nodes.add(_owlCard('Açık durakların hepsini bitirdin!', 'Yeni durakları ailen Ebeveyn bölümünden açabilir. Onlara göster!'));
    }
    for (var i = 0; i < n; i++) {
      final done = _s.stageDone(k.key, i);
      final isCur = i == cur && !done && i < unl;
      final left = i.isEven;
      Widget node;
      if (done) {
        final st = _s.stageStars(k.key, i);
        node = Semantics(
          button: true,
          label: '${i + 1}. durak, tamamlandı, $st yıldız. Tekrar oynamak için dokun.',
          child: GestureDetector(
            onTap: () => _play(i),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  color: k.color,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: k.dark, offset: const Offset(0, 5))],
                ),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 42),
              ),
              const SizedBox(height: 8),
              Row(mainAxisSize: MainAxisSize.min, children: [
                for (var j = 0; j < 3; j++) Icon(Icons.star_rounded, size: 18, color: j < st ? C.sun : C.line),
              ]),
              Text('${i + 1}. durak', style: tCaption(size: 12)),
            ]),
          ),
        );
      } else if (isCur) {
        final circle = Semantics(
          button: true,
          label: '${i + 1}. durak, şimdi başla',
          child: GestureDetector(
            onTap: () => _play(i),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 96,
                height: 96,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: k.color, width: 6),
                  boxShadow: [BoxShadow(color: k.color.withAlpha(90), blurRadius: 18, offset: const Offset(0, 6))],
                ),
                alignment: Alignment.center,
                child: Text('${i + 1}', style: ts(32, w: FontWeight.w700, color: k.dark, height: 1)),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                decoration: BoxDecoration(
                  color: k.color,
                  borderRadius: BorderRadius.circular(999),
                  boxShadow: [BoxShadow(color: k.dark, offset: const Offset(0, 3))],
                ),
                child: Text('BAŞLA', style: ts(13, w: FontWeight.w700, color: Colors.white, spacing: 0.5)),
              ),
            ]),
          ),
        );
        node = Row(mainAxisSize: MainAxisSize.min, children: [
          if (!left) ...[const Owl(size: 76), const SizedBox(width: 6)],
          circle,
          if (left) ...[const SizedBox(width: 6), const Owl(size: 76)],
        ]);
      } else if (i < unl) {
        node = Semantics(
          label: '${i + 1}. durak, önceki durakları bitirince açılır',
          child: Container(
            width: 80,
            height: 80,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: C.line, width: 3),
            ),
            child: Text('${i + 1}', style: ts(28, w: FontWeight.w700, color: C.faint, height: 1)),
          ),
        );
      } else {
        node = Semantics(
          label: '${i + 1}. durak, ebeveyn kilidinde',
          child: Container(
            width: 80,
            height: 80,
            decoration: const BoxDecoration(color: C.track, shape: BoxShape.circle),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.lock_rounded, color: C.faint, size: 26),
              Text('${i + 1}', style: tStrong(color: C.faint, size: 12)),
            ]),
          ),
        );
      }
      nodes.add(Align(alignment: Alignment(left ? -0.5 : 0.5, 0), child: node));
      if (i < n - 1) {
        nodes.add(Align(
          alignment: Alignment.center,
          child: Column(children: [
            for (var d = 0; d < 3; d++)
              Container(
                width: 9,
                height: 9,
                margin: const EdgeInsets.symmetric(vertical: 5),
                decoration: const BoxDecoration(color: Color(0xFFCCD3E3), shape: BoxShape.circle),
              ),
          ]),
        ));
      }
    }
    nodes.add(const SizedBox(height: 22));
    if (_s.demo && extra > 0) {
      nodes.add(AppCard(
        child: Row(children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(color: C.sunSoft, borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.lock_rounded, color: C.sunInk, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Tam sürümde $extra soru daha', style: tStrong(size: 15)),
              const SizedBox(height: 2),
              Text(
                  extraStages > 0
                      ? 'Bu yolun devamında $extraStages durak daha var. Ailen tam sürümü açınca devam edersin.'
                      : 'Ailen tam sürümü açınca devam edersin.',
                  style: tCaption()),
            ]),
          ),
        ]),
      ));
    } else {
      nodes.add(AppCard(
        child: Row(children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(color: C.sunSoft, borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.emoji_events_rounded, color: C.sunDark, size: 30),
          ),
          const SizedBox(width: 14),
          Expanded(child: Text('Yolun sonunda ${k.title} kupası seni bekliyor!', style: tStrong(size: 15))),
        ]),
      ));
    }

    return Scaffold(
      backgroundColor: C.bg,
      body: Column(children: [
        GradientHeader(
          gradient: konuGradient(k),
          radius: 28,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
          child: Column(children: [
            Row(children: [
              IconBtn(Icons.arrow_back_rounded,
                  onTap: () => Navigator.pop(context), label: 'Geri', bg: Colors.white.withAlpha(46), fg: Colors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${k.title} Yolu', style: tTitle(color: Colors.white, size: 21)),
                  Text(
                      _s.demo
                          ? 'Deneme sürümü · $n durak · ${_s.stageSize}\'şar soru'
                          : '$unl / $n durak açık · her durak ${_s.stageSize} soru',
                      style: tCaption(color: Colors.white.withAlpha(225))),
                ]),
              ),
              StarPill(_s.totalStars),
            ]),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(
                  child: ProgressLine(total == 0 ? 0.0 : solved / total,
                      color: Colors.white, track: Colors.white.withAlpha(64))),
              const SizedBox(width: 10),
              Text('$solved / $total soru', style: tLabel(color: Colors.white, size: 12.5)),
            ]),
          ]),
        ),
        Expanded(
          child: Frame(
            child: ListView(padding: const EdgeInsets.fromLTRB(18, 20, 18, 30), children: nodes),
          ),
        ),
      ]),
    );
  }
}

/// 6 · Bölüm girişi: alıştırma + test.
class StageIntro extends StatelessWidget {
  final Konu konu;
  final int stage;
  const StageIntro({super.key, required this.konu, required this.stage});

  @override
  Widget build(BuildContext context) {
    final practice = _s.stagePractice(konu.key, stage);
    final tests = _s.stageTests(konu.key, stage);
    Widget step(String n, String title, String text, Color bg, Color fg) => AppCard(
          child: Row(children: [
            Container(
              width: 48,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(15)),
              child: Text(n, style: ts(22, w: FontWeight.w700, color: fg, height: 1)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: tStrong(size: 16)),
                const SizedBox(height: 2),
                Text(text, style: tCaption()),
              ]),
            ),
          ]),
        );

    void start() {
      final nav = Navigator.of(context);
      if (practice.isEmpty) {
        nav.pushReplacement(MaterialPageRoute(builder: (_) => TestScreen(konu: konu, stage: stage)));
      } else {
        nav.pushReplacement(MaterialPageRoute(
            builder: (_) => PracticeScreen(konu: konu, stage: stage, questions: practice)));
      }
    }

    return Scaffold(
      backgroundColor: C.bg,
      body: ListView(padding: EdgeInsets.zero, children: [
        GradientHeader(
          gradient: konuGradient(konu),
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconBtn(Icons.arrow_back_rounded,
                onTap: () => Navigator.pop(context),
                label: 'Haritaya dön',
                bg: Colors.white.withAlpha(46),
                fg: Colors.white),
            const SizedBox(height: 16),
            Text('${trUpper(konu.title)} YOLU · ${stage + 1}. DURAK', style: tOverline(color: Colors.white.withAlpha(220))),
            const SizedBox(height: 2),
            Text('Hazır mısın?', style: tDisplay(color: Colors.white)),
            const SizedBox(height: 12),
            Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Owl(size: 84),
              const SizedBox(width: 10),
              const Expanded(
                child: Padding(
                  padding: EdgeInsets.only(bottom: 22),
                  child: Bubble('Önce birlikte ısınalım, sonra testte kendi başına dene!'),
                ),
              ),
            ]),
          ]),
        ),
        Frame(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 28),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (practice.isNotEmpty) ...[
                step('1', 'Alıştırma · ${practice.length} soru', 'Yanlış yaparsan ipucu alır, tekrar denersin.', C.okSoft,
                    C.okDark),
                const SizedBox(height: 12),
              ],
              step(practice.isEmpty ? '1' : '2', 'Test · ${tests.length} soru',
                  'Her soruya bir kez cevap verirsin. Doğrular ve yanlışlar test bitince gösterilir.', C.sunSoft, C.sunInk),
              const SizedBox(height: 26),
              PrimaryButton(practice.isEmpty ? 'Teste başla' : 'Alıştırmaya başla',
                  color: konu.color, dark: konu.dark, icon: Icons.play_arrow_rounded, onTap: start),
            ]),
          ),
        ),
      ]),
    );
  }
}

/// 7-9 · Alıştırma: yanlışta ipucu + tekrar deneme, doğruda açıklama.
class PracticeScreen extends StatefulWidget {
  final Konu konu;
  final int stage;
  final List<Question> questions;
  const PracticeScreen({super.key, required this.konu, required this.stage, required this.questions});
  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

enum _Phase { asking, wrong, correct }

class _PracticeScreenState extends State<PracticeScreen> {
  int i = 0;
  _Phase phase = _Phase.asking;
  final Set<String> wrong = {};
  String? lastWrong;

  Question get q => widget.questions[i];

  void _tap(Opt o) {
    if (phase == _Phase.correct || wrong.contains(o.id)) return;
    setState(() {
      if (o.id == q.answer) {
        phase = _Phase.correct;
      } else {
        wrong.add(o.id);
        lastWrong = o.id;
        phase = _Phase.wrong;
      }
    });
  }

  void _next() {
    Speaker.stop();
    if (i + 1 < widget.questions.length) {
      setState(() {
        i++;
        phase = _Phase.asking;
        wrong.clear();
        lastWrong = null;
      });
    } else {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => TestScreen(konu: widget.konu, stage: widget.stage)));
    }
  }

  TileState _state(Opt o) {
    if (phase == _Phase.correct) return o.id == q.answer ? TileState.correct : TileState.dim;
    if (o.id == lastWrong && phase == _Phase.wrong) return TileState.wrong;
    if (wrong.contains(o.id)) return TileState.dim;
    return TileState.normal;
  }

  @override
  Widget build(BuildContext context) {
    final k = widget.konu;
    final last = i + 1 == widget.questions.length;
    return Scaffold(
      backgroundColor: C.bg,
      body: Column(children: [
        QuestionHeader(
          konu: k,
          total: widget.questions.length,
          index: i,
          filled: i + (phase == _Phase.correct ? 1 : 0),
          label: 'ALIŞTIRMA',
          onClose: () => Navigator.pop(context),
          onListen: () => Speaker.say(q.speech),
        ),
        Expanded(
          child: Frame(
            child: ListView(padding: const EdgeInsets.fromLTRB(18, 16, 18, 18), children: [
              QuestionBody(q: q, konu: k, stateOf: _state, onTap: _tap),
            ]),
          ),
        ),
        if (phase == _Phase.wrong)
          _Feedback(
            mood: OwlMood.think,
            accent: C.sunInk,
            soft: C.sunSoft,
            title: 'Neredeyse!',
            subtitle: 'Alıştırmada tekrar deneyebilirsin.',
            body: 'İpucu: ${q.hint ?? 'Soruya bir daha dikkatlice bak.'}',
            button: 'Tekrar dene',
            buttonColor: C.brand,
            buttonDark: C.brandDark,
            onButton: () => setState(() => phase = _Phase.asking),
          ),
        if (phase == _Phase.correct)
          _Feedback(
            mood: OwlMood.happy,
            accent: C.okDark,
            soft: C.okSoft,
            title: 'Harika, doğru!',
            body: q.explanation,
            button: last ? 'Alıştırma bitti · Teste başla' : 'Sonraki alıştırma',
            buttonColor: C.ok,
            buttonDark: C.okDark,
            onButton: _next,
          ),
      ]),
    );
  }
}

class _Feedback extends StatelessWidget {
  final OwlMood mood;
  final Color accent;
  final Color soft;
  final String title;
  final String? subtitle;
  final String body;
  final String button;
  final Color buttonColor;
  final Color buttonDark;
  final VoidCallback onButton;
  const _Feedback({
    required this.mood,
    required this.accent,
    required this.soft,
    required this.title,
    this.subtitle,
    required this.body,
    required this.button,
    required this.buttonColor,
    required this.buttonDark,
    required this.onButton,
  });

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          boxShadow: [BoxShadow(color: Color(0x2218213F), blurRadius: 24, offset: Offset(0, -6))],
        ),
        padding: EdgeInsets.fromLTRB(20, 16, 20, 16 + MediaQuery.of(context).padding.bottom),
        child: Frame(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Owl(size: 58, mood: mood),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: tTitle(color: accent, size: 22)),
                      if (subtitle != null) Text(subtitle!, style: tCaption()),
                    ]),
                  ),
                ]),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: soft, borderRadius: BorderRadius.circular(16)),
                  child: Text(body, style: tBody(color: C.ink, size: 15)),
                ),
                const SizedBox(height: 14),
                PrimaryButton(button, color: buttonColor, dark: buttonDark, onTap: onButton),
              ]),
            ),
          ),
        ),
      );
}

/// 10 · Test: tek cevap, geri bildirim yok.
class TestScreen extends StatefulWidget {
  final Konu konu;
  final int stage;
  const TestScreen({super.key, required this.konu, required this.stage});
  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  late final List<Question> qs = _s.stageTests(widget.konu.key, widget.stage);
  int i = 0;
  String? sel;
  final Map<String, String> answers = {};

  Future<void> _confirm() async {
    Speaker.stop();
    answers[qs[i].id] = sel!;
    if (i + 1 < qs.length) {
      setState(() {
        i++;
        sel = null;
      });
      return;
    }
    final wrong = [for (final q in qs) if (answers[q.id] != q.answer) q.id];
    final r = TestResult(
      grade: _s.grade,
      konu: widget.konu.key,
      stage: widget.stage,
      total: qs.length,
      correct: qs.length - wrong.length,
      answers: answers,
      wrongIds: wrong,
      at: DateTime.now(),
    );
    await _s.saveResult(r);
    await _s.addAnswered(qs.length);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ResultScreen(konu: widget.konu, result: r)));
  }

  Future<void> _exit() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Testten çıkılsın mı?'),
        content: const Text('Bu testteki cevaplar kaydedilmez.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Devam et')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Çık')),
        ],
      ),
    );
    if (leave == true && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final q = qs[i];
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _exit();
      },
      child: Scaffold(
        backgroundColor: C.bg,
        body: Column(children: [
          QuestionHeader(
            konu: widget.konu,
            total: qs.length,
            index: i,
            filled: i,
            label: 'TEST',
            onClose: _exit,
            onListen: () => Speaker.say(q.speech),
          ),
          Expanded(
            child: Frame(
              child: ListView(padding: const EdgeInsets.fromLTRB(18, 16, 18, 12), children: [
                QuestionBody(
                  q: q,
                  konu: widget.konu,
                  stateOf: (o) => o.id == sel ? TileState.selected : TileState.normal,
                  onTap: (o) => setState(() => sel = o.id),
                ),
              ]),
            ),
          ),
          Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Color(0x1018213F), blurRadius: 16, offset: Offset(0, -4))],
            ),
            padding: EdgeInsets.fromLTRB(18, 12, 18, 14 + MediaQuery.of(context).padding.bottom),
            child: Frame(
              child: Column(children: [
                Text('Cevabını seç ve onayla. Doğrular test bitince gösterilir.',
                    textAlign: TextAlign.center, style: tCaption(size: 12)),
                const SizedBox(height: 10),
                PrimaryButton(sel == null ? 'Bir şık seç' : 'Cevabımı onayla', onTap: sel == null ? null : _confirm),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

/// 11 · Test sonucu.
class ResultScreen extends StatelessWidget {
  final Konu konu;
  final TestResult result;
  const ResultScreen({super.key, required this.konu, required this.result});

  @override
  Widget build(BuildContext context) {
    final name = _s.childName;
    final qs = _s.stageTests(konu.key, result.stage);
    final wrong = result.wrongIds;
    final msg = result.stars == 3 ? 'Muhteşemsin' : (result.stars == 2 ? 'Süpersin' : 'Güzel deneme');
    return Scaffold(
      backgroundColor: C.bg,
      body: ListView(padding: EdgeInsets.zero, children: [
        GradientHeader(
          padding: const EdgeInsets.fromLTRB(22, 12, 22, 64),
          radius: 32,
          child: Column(children: [
            Text('${konu.title} Yolu · ${result.stage + 1}. durak', style: tCaption(color: Colors.white.withAlpha(215))),
            const SizedBox(height: 2),
            Text('Test bitti!', style: tDisplay(color: Colors.white)),
            const SizedBox(height: 18),
            Ring(
              result.total == 0 ? 0.0 : result.correct / result.total,
              size: 150,
              stroke: 12,
              color: C.sun,
              track: Colors.white.withAlpha(46),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text.rich(TextSpan(children: [
                  TextSpan(text: '${result.correct}', style: ts(42, w: FontWeight.w700, color: Colors.white, height: 1)),
                  TextSpan(text: '/${result.total}', style: ts(20, w: FontWeight.w500, color: Colors.white.withAlpha(180))),
                ])),
                Text('doğru', style: tCaption(color: Colors.white.withAlpha(215))),
              ]),
            ),
            const SizedBox(height: 14),
            Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (var j = 0; j < 3; j++)
                Icon(Icons.star_rounded,
                    size: j == 1 ? 48 : 38, color: j < result.stars ? C.sun : Colors.white.withAlpha(70)),
            ]),
          ]),
        ),
        Transform.translate(
          offset: const Offset(0, -44),
          child: Frame(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                AppCard(
                  child: Column(children: [
                    Row(children: [
                      const Owl(size: 58, mood: OwlMood.happy),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(name.isEmpty ? '$msg!' : '$msg $name!', style: tTitle(size: 17)),
                          Text(
                              wrong.isEmpty
                                  ? '${result.stars} yıldız kazandın. Hepsi doğru, tebrikler!'
                                  : '${result.stars} yıldız kazandın. ${wrong.length} soruyu birlikte inceleyelim.',
                              style: tCaption()),
                        ]),
                      ),
                    ]),
                    const SizedBox(height: 14),
                    Row(children: [
                      for (final q in qs)
                        Expanded(
                          child: Container(
                            height: 10,
                            margin: const EdgeInsets.symmetric(horizontal: 2.5),
                            decoration: BoxDecoration(
                              color: wrong.contains(q.id) ? C.warn : C.ok,
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                    ]),
                  ]),
                ),
                const SizedBox(height: 22),
                if (wrong.isNotEmpty) ...[
                  PrimaryButton(wrong.length == 1 ? 'Yanlışımı incele' : 'Yanlışlarımı incele',
                      icon: Icons.school_rounded,
                      onTap: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => ReviewScreen(konu: konu, result: result)))),
                  const SizedBox(height: 12),
                ],
                SecondaryButton('Haritaya dön', onTap: () => Navigator.pop(context)),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}

/// 12 · Yanlışları açıklamalarla inceleme.
class ReviewScreen extends StatefulWidget {
  final Konu konu;
  final TestResult result;
  const ReviewScreen({super.key, required this.konu, required this.result});
  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  int i = 0;

  @override
  Widget build(BuildContext context) {
    final ids = widget.result.wrongIds;
    final q = _s.byId(ids[i]);
    final mine = widget.result.answers[q.id];
    final all = _s.stageTests(widget.konu.key, widget.result.stage);
    final pos = all.indexWhere((x) => x.id == q.id) + 1;

    Widget box(String label, Opt? o, Color bg, Color border, Color fg, IconData icon) => Expanded(
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: bg, borderRadius: BorderRadius.circular(18), border: Border.all(color: border, width: 2)),
            child: Column(children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icon, size: 16, color: fg),
                const SizedBox(width: 4),
                Flexible(child: Text(label, style: tStrong(color: fg, size: 12.5))),
              ]),
              const SizedBox(height: 8),
              if (o == null)
                Text('-', style: tTitle())
              else if (o.image != null)
                SizedBox(height: 96, child: Image.asset('assets/${o.image}', fit: BoxFit.contain))
              else
                Text(o.text ?? '', textAlign: TextAlign.center, style: ts(16, w: FontWeight.w500)),
            ]),
          ),
        );

    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: Frame(
          child: ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 24), children: [
            Row(children: [
              IconBtn(Icons.arrow_back_rounded, onTap: () => Navigator.pop(context), label: 'Sonuca dön', bg: Colors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Birlikte öğrenelim', style: tTitle()),
                  Text('Yanlış ${i + 1} / ${ids.length} · testin $pos. sorusu', style: tCaption()),
                ]),
              ),
            ]),
            const SizedBox(height: 14),
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (q.beceri != null) ...[SkillChip(q.beceri!, color: widget.konu.dark), const SizedBox(height: 10)],
                Text(q.stem, style: ts(15, w: FontWeight.w500, height: 1.5)),
                if (q.image != null) ...[
                  const SizedBox(height: 10),
                  Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 220),
                      child: Image.asset('assets/${q.image}', fit: BoxFit.contain),
                    ),
                  ),
                ],
              ]),
            ),
            const SizedBox(height: 12),
            Row(children: [
              box('Senin cevabın', mine == null ? null : q.optionById(mine), C.errSoft, C.err, C.errDark,
                  Icons.close_rounded),
              const SizedBox(width: 10),
              box('Doğru cevap', q.optionById(q.answer), C.okSoft, C.ok, C.okDark, Icons.check_rounded),
            ]),
            const SizedBox(height: 12),
            AppCard(
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Owl(size: 50),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Neden?', style: tStrong(color: widget.konu.dark, size: 15)),
                    const SizedBox(height: 2),
                    Text(q.explanation, style: tBody(color: C.ink, size: 14.5)),
                  ]),
                ),
              ]),
            ),
            if (q.veliNotu != null) ...[
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(color: C.sunSoft, borderRadius: BorderRadius.circular(20)),
                child: Theme(
                  data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    leading: const Icon(Icons.family_restroom_rounded, color: C.sunInk),
                    title: Text('Ebeveyn için not', style: tStrong(color: C.sunInk, size: 15)),
                    subtitle: q.beceri == null ? null : Text('Beceri: ${q.beceri}', style: tCaption(color: C.sunInk)),
                    iconColor: C.sunInk,
                    collapsedIconColor: C.sunInk,
                    expandedAlignment: Alignment.centerLeft,
                    expandedCrossAxisAlignment: CrossAxisAlignment.start,
                    childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                    children: [Text(q.veliNotu!, style: tBody(color: C.sunInk))],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 22),
            Row(children: [
              Expanded(child: SecondaryButton('Önceki', onTap: i == 0 ? null : () => setState(() => i--))),
              const SizedBox(width: 10),
              Expanded(
                child: PrimaryButton(i + 1 < ids.length ? 'Sonraki' : 'Bitir',
                    onTap: () => i + 1 < ids.length ? setState(() => i++) : Navigator.pop(context)),
              ),
            ]),
          ]),
        ),
      ),
    );
  }
}
