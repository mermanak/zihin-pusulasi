import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data.dart';
import '../theme.dart';
import '../widgets.dart';
import 'setup_screens.dart';

AppState get _s => AppState.instance;

/// 13 · Ebeveyn şifresi ile giriş.
class ParentGate extends StatefulWidget {
  const ParentGate({super.key});
  @override
  State<ParentGate> createState() => _ParentGateState();
}

class _ParentGateState extends State<ParentGate> {
  String v = '';
  bool wrong = false;

  void _digit(String d) {
    if (v.length >= 4) return;
    setState(() {
      v += d;
      wrong = false;
    });
    if (v.length == 4) {
      if (_s.checkPin(v)) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ParentPanel()));
      } else {
        setState(() {
          v = '';
          wrong = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => FormPage(
        icon: Icons.lock_rounded,
        tint: C.brand,
        appBarTitle: 'Çocuk ekranına dön',
        title: 'Ebeveyn şifreniz',
        text: 'Sonuçları ve ayarları görmek için belirlediğiniz 4 haneli şifreyi girin.',
        children: [
          PinDots(v.length),
          if (wrong)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text('Şifre yanlış. Tekrar deneyin.', textAlign: TextAlign.center, style: tLabel(color: C.err)),
            ),
          const SizedBox(height: 18),
          PinPad(
            onDigit: _digit,
            onDelete: () => setState(() {
              if (v.isNotEmpty) v = v.substring(0, v.length - 1);
            }),
          ),
          const SizedBox(height: 10),
          Center(
            child: TextButton(
              onPressed: () =>
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ForgotScreen())),
              child: const Text('Şifremi unuttum'),
            ),
          ),
        ],
      );
}

/// 14 · Şifremi unuttum (güvenlik sorusu).
class ForgotScreen extends StatefulWidget {
  const ForgotScreen({super.key});
  @override
  State<ForgotScreen> createState() => _ForgotScreenState();
}

class _ForgotScreenState extends State<ForgotScreen> {
  final answer = TextEditingController();
  bool wrong = false;

  @override
  void dispose() {
    answer.dispose();
    super.dispose();
  }

  void _check() {
    if (_s.checkSecurity(answer.text)) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => PinSetupScreen(
          onDone: (ctx) =>
              Navigator.of(ctx).pushReplacement(MaterialPageRoute(builder: (_) => const ParentPanel())),
        ),
      ));
    } else {
      setState(() => wrong = true);
    }
  }

  @override
  Widget build(BuildContext context) => FormPage(
        icon: Icons.shield_rounded,
        tint: C.sunInk,
        title: 'Şifrenizi yenileyin',
        text: 'Kurulumda seçtiğiniz güvenlik sorusunu cevaplayın. Cevap doğruysa yeni şifre belirlersiniz; çocuğunuzun ilerlemesi silinmez.',
        children: [
          AppCard(
            shadow: false,
            border: Border.all(color: C.line, width: 1.5),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('GÜVENLİK SORUNUZ', style: tOverline()),
              const SizedBox(height: 2),
              Text(securityQuestions[_s.securityIndex], style: tStrong(size: 16)),
            ]),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: answer,
            onChanged: (_) => setState(() => wrong = false),
            style: ts(15),
            decoration: const InputDecoration(hintText: 'Cevabınız'),
          ),
          if (wrong)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('Cevap eşleşmedi. Tekrar deneyin.', style: tLabel(color: C.err)),
            ),
          const SizedBox(height: 22),
          PrimaryButton('Yeni şifre belirle', onTap: answer.text.trim().isEmpty ? null : _check),
        ],
      );
}

/// 15 · Ebeveyn paneli (sonuçlar ve ayarlar).
class ParentPanel extends StatefulWidget {
  const ParentPanel({super.key});
  @override
  State<ParentPanel> createState() => _ParentPanelState();
}

class _ParentPanelState extends State<ParentPanel> {
  Future<void> _changeGrade() async {
    final g = await showDialog<int>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('Sınıfı seçin'),
        children: [
          for (final g in grades)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(c, g),
              child: Text('$g. sınıf', style: g == _s.grade ? tStrong(color: C.brand, size: 15) : tLabel(size: 15)),
            ),
        ],
      ),
    );
    if (g != null) {
      await _s.setGrade(g);
      setState(() {});
    }
  }

  Future<void> _changeName() async {
    final ctrl = TextEditingController(text: _s.childName);
    final n = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Çocuğun adı'),
        content: TextField(controller: ctrl, autofocus: true, style: ts(15)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('Kaydet')),
        ],
      ),
    );
    if (n != null) {
      await _s.setChildName(n);
      setState(() {});
    }
  }

  void _changePin() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => PinSetupScreen(onDone: (ctx) {
        Navigator.of(ctx).pop();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ebeveyn şifresi değiştirildi.')));
      }),
    ));
  }

  Future<void> _resetLocks() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Kilitler ilk hâline dönsün mü?'),
        content: Text('Her bölümde yalnızca ilk ${AppState.defaultUnlocked} durak açık kalır. Çözülmüş testler ve yıldızlar silinmez.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Evet')),
        ],
      ),
    );
    if (ok == true) {
      for (final k in konular) {
        await _s.resetLock(k.key);
      }
      setState(() {});
    }
  }

  // ---------------------------------------------------------- geri bildirim
  String _query(Map<String, String> p) =>
      p.entries.map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}').join('&');

  Uri get _mailUri => Uri(
        scheme: 'mailto',
        path: devMail,
        query: _query({
          'subject': '$appName geri bildirim',
          'body': 'Merhaba,\n\n\n\n---\nUygulama sürümü: $appVersion${_s.demo ? ' (deneme)' : ''}\nSınıf: ${_s.grade}',
        }),
      );

  Uri get _instagramUri => Uri.parse('https://www.instagram.com/$devInstagram/');

  Uri get _twitterUri => Uri.parse('https://x.com/$devTwitter');

  Future<void> _copy(String text, String message) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _open(Uri uri, String copyText, String what) async {
    var ok = false;
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      ok = false;
    }
    if (!ok) await _copy(copyText, '$what açılamadı. Adres panoya kopyalandı: $copyText');
  }

  Widget _contactRow(Widget leading, String label, String value, VoidCallback onOpen, VoidCallback onCopy) => Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onOpen,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              leading,
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: tCaption(size: 12)),
                  Text(value, style: tStrong(size: 14.5)),
                ]),
              ),
              IconButton(
                onPressed: onCopy,
                tooltip: 'Kopyala',
                icon: const Icon(Icons.copy_rounded, size: 20, color: C.muted),
              ),
              const Icon(Icons.open_in_new_rounded, size: 18, color: C.faint),
            ]),
          ),
        ),
      );

  Widget _feedbackCard() => AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.forum_rounded, color: C.brand, size: 20),
            const SizedBox(width: 8),
            Expanded(child: Text('Geri bildirim ve iletişim', style: tTitle(size: 16))),
          ]),
          const SizedBox(height: 4),
          Text(
              _s.demo
                  ? 'Uygulama deneme sürümünde. Beğendiğiniz, eksik bulduğunuz ya da hatalı gördüğünüz her şeyi geliştiriciye yazabilirsiniz.'
                  : 'Öneri, soru ya da hata bildirimi için geliştiriciye yazabilirsiniz.',
              style: tCaption()),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: C.bg, borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              Container(
                width: 46,
                height: 46,
                alignment: Alignment.center,
                decoration: const BoxDecoration(gradient: kHeaderGradient, shape: BoxShape.circle),
                child: Text(devName.split(' ').where((w) => w.isNotEmpty).map((w) => trUpper(w[0])).take(3).join(),
                    style: tStrong(color: Colors.white, size: 13.5)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('GELİŞTİRİCİ', style: tOverline()),
                  Text(devName, style: tStrong(size: 15)),
                  Text(devTitle, style: tCaption(size: 12.5)),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 6),
          _contactRow(
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: C.brandSoft, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.mail_rounded, color: C.brand, size: 21),
            ),
            'E-posta',
            devMail,
            () => _open(_mailUri, devMail, 'E-posta uygulaması'),
            () => _copy(devMail, 'E-posta adresi kopyalandı.'),
          ),
          const Divider(),
          _contactRow(
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.bottomLeft,
                  end: Alignment.topRight,
                  colors: [Color(0xFFF9A825), Color(0xFFE1306C), Color(0xFF833AB4)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 20),
            ),
            'Instagram',
            '@$devInstagram',
            () => _open(_instagramUri, '@$devInstagram', 'Instagram'),
            () => _copy('@$devInstagram', 'Instagram hesabı kopyalandı.'),
          ),
          const Divider(),
          _contactRow(
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: const Color(0xFF0F1419), borderRadius: BorderRadius.circular(12)),
              child: Text('X', style: ts(19, w: FontWeight.w700, color: Colors.white, height: 1)),
            ),
            'X (Twitter)',
            '@$devTwitter',
            () => _open(_twitterUri, '@$devTwitter', 'X (Twitter)'),
            () => _copy('@$devTwitter', 'X (Twitter) hesabı kopyalandı.'),
          ),
          const SizedBox(height: 4),
          Text('Sürüm $appVersion${_s.demo ? ' · deneme' : ''}', style: tCaption(size: 11.5, color: C.faint)),
        ]),
      );

  Widget _lockRow(Konu k) {
    final u = _s.unlockedCount(k.key);
    final n = _s.stageCount(k.key);
    final full = u >= n;
    final compact = TextButton.styleFrom(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      minimumSize: const Size(0, 36),
      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(color: k.light, borderRadius: BorderRadius.circular(11)),
          child: Icon(k.icon, color: k.dark, size: 19),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(k.title, style: tStrong()),
            Text(full ? 'Bütün duraklar açık ($n)' : '$u / $n durak açık', style: tCaption(size: 12)),
          ]),
        ),
        TextButton(
          style: compact,
          onPressed: full
              ? null
              : () async {
                  await _s.unlockMore(k.key);
                  setState(() {});
                },
          child: const Text('+1 durak'),
        ),
        TextButton(
          style: compact,
          onPressed: full
              ? null
              : () async {
                  await _s.unlockAll(k.key);
                  setState(() {});
                },
          child: const Text('Hepsini aç'),
        ),
      ]),
    );
  }

  Widget _barRow(String label, double v, String right, Color color) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(label, style: tLabel(size: 13.5))),
            Text(right, style: tStrong(size: 13.5)),
          ]),
          const SizedBox(height: 6),
          ProgressLine(v, color: color),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final all = _s.results.where((r) => r.grade == _s.grade).toList();
    final weekAgo = DateTime.now().subtract(const Duration(days: 7));
    final week = all.where((r) => r.at.isAfter(weekAgo)).fold<int>(0, (a, r) => a + r.total);
    final tot = all.fold<int>(0, (a, r) => a + r.total);
    final cor = all.fold<int>(0, (a, r) => a + r.correct);

    final perKonu = <String, List<int>>{};
    for (final r in all) {
      final e = perKonu.putIfAbsent(r.konu, () => [0, 0]);
      e[0] += r.correct;
      e[1] += r.total;
    }
    double ratio(List<int> v) => v[1] == 0 ? 0.0 : v[0] / v[1];
    final skills = _s.skillStats().entries.where((e) => e.value[1] > 0).toList()
      ..sort((a, b) => ratio(a.value).compareTo(ratio(b.value)));
    final weak = skills.where((e) => e.value[1] >= 3 && ratio(e.value) < 0.75).toList();
    final recent = all.reversed.take(5).toList();
    final name = _s.childName;
    final fullCount = konular.fold<int>(0, (a, k) => a + _s.fullTestCount(k.key));
    final openCount = konular.fold<int>(0, (a, k) => a + _s.tests(k.key).length);

    Widget stat(String label, String value, String unit, Color color, IconData icon) => Expanded(
          child: AppCard(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, size: 20, color: color),
              const SizedBox(height: 6),
              Text(value, style: ts(22, w: FontWeight.w700, color: C.ink, height: 1.1)),
              Text('$label · $unit', style: tCaption(size: 11.5)),
            ]),
          ),
        );

    Widget setting(IconData icon, String label, String value, VoidCallback onTap) => ListTile(
          onTap: onTap,
          leading: Icon(icon, color: C.muted),
          title: Text(label, style: tLabel(size: 14.5)),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(value, style: tCaption(size: 13)),
            const Icon(Icons.chevron_right_rounded, color: C.faint),
          ]),
        );

    return Scaffold(
      backgroundColor: C.bg,
      body: Column(children: [
        Container(
          decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: C.line))),
          child: SafeArea(
            bottom: false,
            child: Frame(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
                child: Row(children: [
                  Container(
                    width: 46,
                    height: 46,
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(color: C.brandSoft, shape: BoxShape.circle),
                    child: name.isEmpty
                        ? const Icon(Icons.child_care_rounded, color: C.brand)
                        : Text(trUpper(name.substring(0, 1)), style: tTitle(color: C.brand, size: 18)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('EBEVEYN PANELİ', style: tOverline()),
                      Text('${name.isEmpty ? 'Çocuğunuz' : name} · ${_s.grade}. sınıf', style: tTitle()),
                    ]),
                  ),
                  IconBtn(Icons.lock_rounded, onTap: () => Navigator.pop(context), label: 'Kilitle ve çık'),
                ]),
              ),
            ),
          ),
        ),
        Expanded(
          child: Frame(
            child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 28), children: [
              if (_s.demo) ...[
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
                  decoration: BoxDecoration(gradient: kHeaderGradient, borderRadius: BorderRadius.circular(20)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const DemoBadge(onDark: true),
                    const SizedBox(height: 10),
                    Text('Şu anda deneme sürümünü kullanıyorsunuz.', style: tStrong(color: Colors.white, size: 15)),
                    const SizedBox(height: 4),
                    Text(
                        '${_s.grade}. sınıf için $fullCount soru hazırlandı; bu sürümde bunların $openCount tanesi açık. '
                        'Her bölümde 12 soru kolaydan zora sıralı. Tam sürümde her bölüm 8 durağa ayrılır ve yeni durakları siz açarsınız.',
                        style: tCaption(color: Colors.white.withAlpha(225), size: 13)),
                    const SizedBox(height: 12),
                    Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => _open(_mailUri, devMail, 'E-posta uygulaması'),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.rate_review_rounded, color: C.brand, size: 18),
                            const SizedBox(width: 8),
                            Text('Görüşünüzü yazın', style: tStrong(color: C.brand, size: 13.5)),
                          ]),
                        ),
                      ),
                    ),
                  ]),
                ),
                const SizedBox(height: 14),
              ],
              Row(children: [
                stat('Bu hafta', '$week', 'soru', C.brand, Icons.calendar_today_rounded),
                const SizedBox(width: 10),
                stat('Başarı', tot == 0 ? '-' : '%${(100 * cor / tot).round()}', 'doğru', C.ok, Icons.trending_up_rounded),
                const SizedBox(width: 10),
                stat('Yıldız', '${_s.totalStars}', 'toplam', C.sunDark, Icons.star_rounded),
              ]),
              const SizedBox(height: 14),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Bölümlere göre başarı', style: tTitle(size: 16)),
                  const SizedBox(height: 12),
                  for (final k in konular)
                    Builder(builder: (_) {
                      final e = perKonu[k.key];
                      final pct = (e == null || e[1] == 0) ? null : e[0] / e[1];
                      return _barRow(k.title, pct ?? 0.0, pct == null ? 'henüz yok' : '%${(pct * 100).round()}', k.color);
                    }),
                ]),
              ),
              if (skills.isNotEmpty) ...[
                const SizedBox(height: 14),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Becerilere göre başarı', style: tTitle(size: 16)),
                    Text('En çok zorlandığı beceriler üstte', style: tCaption()),
                    const SizedBox(height: 12),
                    for (final e in skills.take(8))
                      _barRow(
                          e.key,
                          ratio(e.value),
                          '${e.value[0]}/${e.value[1]} · %${(ratio(e.value) * 100).round()}',
                          ratio(e.value) < 0.5 ? C.err : (ratio(e.value) < 0.75 ? C.warn : C.ok)),
                  ]),
                ),
              ],
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: C.sunSoft, borderRadius: BorderRadius.circular(20)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.tips_and_updates_rounded, color: C.sunInk, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text('Birlikte çalışmanızı önerdiklerimiz', style: tStrong(color: C.sunInk, size: 15))),
                  ]),
                  const SizedBox(height: 8),
                  if (skills.isEmpty)
                    Text('Henüz yeterli test yok. Birkaç test çözüldükten sonra burada öneriler görünecek.',
                        style: tBody(color: C.sunInk))
                  else if (weak.isEmpty)
                    Text('Şu ana kadar çözülen testlerde zorlandığı belirgin bir beceri yok.', style: tBody(color: C.sunInk))
                  else
                    for (final w in weak.take(2))
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${w.key} · ${w.value[1]} sorunun ${w.value[0]} tanesi doğru',
                              style: tStrong(color: C.sunInk, size: 13.5)),
                          if (_s.skillNote(w.key) != null) Text(_s.skillNote(w.key)!, style: tBody(color: C.sunInk, size: 13.5)),
                        ]),
                      ),
                ]),
              ),
              if (!_s.demo) ...[
                const SizedBox(height: 14),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.lock_open_rounded, color: C.brand, size: 20),
                      const SizedBox(width: 8),
                      Text('Durakları açın', style: tTitle(size: 16)),
                    ]),
                    const SizedBox(height: 4),
                    Text(
                        'Her bölümde ilk ${AppState.defaultUnlocked} durak açıktır. Çocuğunuz hazır olduğunda yeni durakları buradan açabilirsiniz. Duraklar zorluk sırasıyla ilerler.',
                        style: tCaption()),
                    const SizedBox(height: 8),
                    for (final k in konular) _lockRow(k),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(onPressed: _resetLocks, child: const Text('Kilitleri ilk hâline getir')),
                    ),
                  ]),
                ),
              ],
              if (recent.isNotEmpty) ...[
                const SizedBox(height: 14),
                AppCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Son testler', style: tTitle(size: 16)),
                    const SizedBox(height: 6),
                    for (final r in recent)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Row(children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(color: konuOf(r.konu).light, borderRadius: BorderRadius.circular(10)),
                            child: Icon(konuOf(r.konu).icon, size: 17, color: konuOf(r.konu).dark),
                          ),
                          const SizedBox(width: 10),
                          Expanded(child: Text('${konuOf(r.konu).title} · ${r.stage + 1}. durak', style: tLabel(size: 13.5))),
                          Text('${r.correct}/${r.total}', style: tStrong(size: 13.5)),
                          const SizedBox(width: 10),
                          Text('${r.at.day}.${r.at.month}', style: tCaption(size: 12)),
                        ]),
                      ),
                  ]),
                ),
              ],
              const SizedBox(height: 14),
              AppCard(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(children: [
                  setting(Icons.school_rounded, 'Sınıfı değiştir', '${_s.grade}. sınıf', _changeGrade),
                  const Divider(indent: 16, endIndent: 16),
                  setting(Icons.person_rounded, 'Çocuğun adı', name.isEmpty ? '-' : name, _changeName),
                  const Divider(indent: 16, endIndent: 16),
                  SwitchListTile(
                    value: _s.ttsOn,
                    onChanged: (v) async {
                      await _s.setTts(v);
                      setState(() {});
                    },
                    secondary: const Icon(Icons.record_voice_over_rounded, color: C.muted),
                    title: Text('Sesli okuma', style: tLabel(size: 14.5)),
                  ),
                  const Divider(indent: 16, endIndent: 16),
                  setting(Icons.password_rounded, 'Ebeveyn şifresini değiştir', '••••', _changePin),
                ]),
              ),
              const SizedBox(height: 14),
              _feedbackCard(),
              const SizedBox(height: 20),
              PrimaryButton('Kilitle ve çocuk moduna dön', icon: Icons.lock_rounded, onTap: () => Navigator.pop(context)),
              const SizedBox(height: 12),
              Text('Hesap yok, reklam yok. Bütün veriler yalnızca bu cihazda saklanır.',
                  textAlign: TextAlign.center, style: tCaption(size: 12)),
            ]),
          ),
        ),
      ]),
    );
  }
}
