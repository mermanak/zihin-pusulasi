import 'package:flutter/material.dart';

import '../data.dart';
import '../theme.dart';
import '../widgets.dart';
import 'child_screens.dart';

/// 1 · Karşılama: sınıf ve (isteğe bağlı) çocuğun adı.
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  int grade = 1;
  final name = TextEditingController();

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  Future<void> _next() async {
    final s = AppState.instance;
    await s.setGrade(grade);
    await s.setChildName(name.text);
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => PinSetupScreen(
        stepLabel: true,
        onDone: (ctx) => Navigator.of(ctx).push(MaterialPageRoute(builder: (_) => const SecuritySetupScreen())),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.instance;
    final nTest = st.all.where((q) => q.grade == grade && !q.isPractice).length;
    final nDemo = st.all.where((q) => q.grade == grade && !q.isPractice && q.demoSira != null).length;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(gradient: kHeaderGradient),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 18, 24, 50),
                child: Column(children: [
                  const Owl(size: 104),
                  const SizedBox(height: 6),
                  Text(appName, textAlign: TextAlign.center, style: tDisplay(color: Colors.white)),
                  const SizedBox(height: 4),
                  Text(appTagline,
                      textAlign: TextAlign.center, style: ts(14, color: Colors.white.withAlpha(215))),
                  if (st.demo) ...[const SizedBox(height: 14), const DemoBadge(onDark: true)],
                ]),
              ),
            ),
          ),
          Transform.translate(
            offset: const Offset(0, -28),
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              padding: const EdgeInsets.fromLTRB(22, 24, 22, 8),
              child: Frame(
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Text('Çocuğunuzun sınıfı', style: tStrong(size: 15)),
                  const SizedBox(height: 10),
                  _GradePicker(value: grade, onChanged: (g) => setState(() => grade = g)),
                  const SizedBox(height: 20),
                  if (st.demo)
                    _Prop(Icons.menu_book_rounded, C.brand, 'Deneme sürümü: $nDemo soru',
                        'Sözel, görsel ve matris bölümlerinden 12\'şer soru, kolaydan zora. Uygulamada bu sınıf için $nTest soru hazırlandı; tam sürümde hepsi açılacak.')
                  else
                    _Prop(Icons.menu_book_rounded, C.brand, '$grade. sınıf için $nTest özgün soru',
                        'Sözel, görsel ve matris bölümleri; her bölümde kolaydan zora 8 durak.'),
                  const _Prop(Icons.psychology_rounded, C.ok, 'Her soruda beceri ve açıklama',
                      'Yanlışlar çözümüyle gösterilir. Veli notları, çocuğunuzla nasıl çalışacağınızı anlatır.'),
                  if (!st.demo)
                    const _Prop(Icons.lock_open_rounded, C.sunInk, 'Durakları siz açarsınız',
                        'İlk iki durak açık gelir. Çocuğunuz hazır olduğunda yenilerini ebeveyn panelinden açarsınız.'),
                  const SizedBox(height: 6),
                  Text.rich(TextSpan(children: [
                    TextSpan(text: 'Çocuğunuzun adı ', style: tStrong(size: 15)),
                    TextSpan(text: '(isteğe bağlı)', style: tCaption()),
                  ])),
                  const SizedBox(height: 8),
                  TextField(
                    controller: name,
                    textCapitalization: TextCapitalization.words,
                    style: ts(15),
                    decoration: const InputDecoration(hintText: 'Örneğin: Ada'),
                  ),
                  const SizedBox(height: 22),
                  PrimaryButton('Devam et', onTap: _next),
                  const SizedBox(height: 16),
                  const Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 16,
                    runSpacing: 8,
                    children: [
                      _Trust(Icons.block_rounded, 'Reklam yok'),
                      _Trust(Icons.no_accounts_rounded, 'Hesap gerekmez'),
                      _Trust(Icons.phone_android_rounded, 'Veriler cihazda'),
                    ],
                  ),
                  const SizedBox(height: 12),
                ]),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class _GradePicker extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const _GradePicker({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(color: C.bg, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          for (final g in grades)
            Expanded(
              child: Semantics(
                button: true,
                selected: g == value,
                label: '$g. sınıf',
                child: GestureDetector(
                  onTap: () => onChanged(g),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: g == value ? Colors.white : Colors.transparent,
                      borderRadius: BorderRadius.circular(11),
                      boxShadow: g == value
                          ? const [BoxShadow(color: Color(0x1F18213F), blurRadius: 8, offset: Offset(0, 2))]
                          : null,
                    ),
                    child: Text('$g. sınıf',
                        style: g == value ? tStrong(color: C.brand, size: 14) : tLabel(color: C.muted, size: 14)),
                  ),
                ),
              ),
            ),
        ]),
      );
}

class _Prop extends StatelessWidget {
  final IconData icon;
  final Color tint;
  final String title;
  final String text;
  const _Prop(this.icon, this.tint, this.title, this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: tint.withAlpha(28), borderRadius: BorderRadius.circular(13)),
            child: Icon(icon, color: tint, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: tStrong()),
              const SizedBox(height: 2),
              Text(text, style: tCaption()),
            ]),
          ),
        ]),
      );
}

class _Trust extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Trust(this.icon, this.text);
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 16, color: C.muted),
        const SizedBox(width: 5),
        Text(text, style: tCaption(size: 12)),
      ]);
}

/// Kurulum ve şifre ekranlarının ortak iskeleti.
class FormPage extends StatelessWidget {
  final IconData icon;
  final Color tint;
  final String? step;
  final String title;
  final String text;
  final List<Widget> children;
  final String? appBarTitle;
  const FormPage(
      {super.key,
      required this.icon,
      required this.tint,
      this.step,
      required this.title,
      required this.text,
      required this.children,
      this.appBarTitle});

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: C.bg,
        appBar: AppBar(
          backgroundColor: C.bg,
          title: appBarTitle == null ? null : Text(appBarTitle!, style: tLabel(color: C.brand, size: 15)),
        ),
        body: SafeArea(
          top: false,
          child: Frame(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 0, 22, 24),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(color: tint.withAlpha(30), borderRadius: BorderRadius.circular(16)),
                    child: Icon(icon, color: tint, size: 28),
                  ),
                  const SizedBox(width: 12),
                  if (step != null) Pill(step!, bg: Colors.white, fg: tint, size: 12),
                ]),
                const SizedBox(height: 16),
                Text(title, style: tDisplay()),
                const SizedBox(height: 6),
                Text(text, style: tBody(color: C.muted)),
                const SizedBox(height: 20),
                ...children,
              ]),
            ),
          ),
        ),
      );
}

/// 2 · Ebeveyn şifresi oluşturma (iki kez girilir). Kurulumda, şifre değişikliğinde ve sıfırlamada kullanılır.
class PinSetupScreen extends StatefulWidget {
  final bool stepLabel;
  final void Function(BuildContext context) onDone;
  const PinSetupScreen({super.key, required this.onDone, this.stepLabel = false});
  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  String first = '';
  String second = '';
  int step = 1;
  bool mismatch = false;

  void _digit(String d) {
    setState(() {
      if (step == 1) {
        if (first.length < 4) first += d;
        if (first.length == 4) {
          step = 2;
          mismatch = false;
        }
      } else if (second.length < 4) {
        second += d;
        if (second.length == 4 && second != first) {
          second = '';
          mismatch = true;
        } else {
          mismatch = false;
        }
      }
    });
  }

  void _delete() => setState(() {
        if (step == 1 && first.isNotEmpty) first = first.substring(0, first.length - 1);
        if (step == 2 && second.isNotEmpty) second = second.substring(0, second.length - 1);
      });

  void _reset() => setState(() {
        first = '';
        second = '';
        step = 1;
        mismatch = false;
      });

  Future<void> _save() async {
    await AppState.instance.setPin(first);
    if (!mounted) return;
    widget.onDone(context);
  }

  @override
  Widget build(BuildContext context) {
    final done = step == 2 && second.length == 4 && second == first;
    return FormPage(
      icon: Icons.lock_rounded,
      tint: C.brand,
      step: widget.stepLabel ? 'ADIM $step / 3' : null,
      title: step == 1 ? 'Ebeveyn şifrenizi belirleyin' : 'Şifrenizi tekrar girin',
      text: step == 1
          ? '4 haneli bir şifre seçin. Sonuçlara ve ayarlara yalnızca bu şifreyle girilebilir.'
          : 'Doğru yazdığınızdan emin olmak için aynı şifreyi bir kez daha girin.',
      children: [
        PinDots(step == 1 ? first.length : second.length),
        if (mismatch)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text('Şifreler aynı değil. Lütfen tekrar deneyin.',
                textAlign: TextAlign.center, style: tLabel(color: C.err)),
          ),
        const SizedBox(height: 18),
        PinPad(onDigit: _digit, onDelete: _delete, extraLabel: 'Baştan', onExtra: _reset),
        const SizedBox(height: 18),
        PrimaryButton('Devam et', onTap: done ? _save : null),
        const SizedBox(height: 12),
        Text('Bu şifreyle çocuğunuzun sonuçlarını görürsünüz. Çocuğunuzla paylaşmayın.',
            textAlign: TextAlign.center, style: tCaption()),
      ],
    );
  }
}

/// 3 · Güvenlik sorusu.
class SecuritySetupScreen extends StatefulWidget {
  const SecuritySetupScreen({super.key});
  @override
  State<SecuritySetupScreen> createState() => _SecuritySetupScreenState();
}

class _SecuritySetupScreenState extends State<SecuritySetupScreen> {
  int pick = 0;
  final answer = TextEditingController();

  @override
  void dispose() {
    answer.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    final s = AppState.instance;
    await s.setSecurity(pick, answer.text);
    await s.finishSetup();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const ChildHome()), (_) => false);
  }

  @override
  Widget build(BuildContext context) => FormPage(
        icon: Icons.shield_rounded,
        tint: C.sunInk,
        step: 'ADIM 3 / 3',
        title: 'Bir güvenlik sorusu seçin',
        text: 'Şifrenizi unutursanız bu sorunun cevabıyla yeni şifre belirlersiniz. Çocuğunuzun ilerlemesi silinmez.',
        children: [
          for (var i = 0; i < securityQuestions.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                shadow: false,
                border: Border.all(color: pick == i ? C.brand : C.line, width: pick == i ? 2 : 1.5),
                color: pick == i ? C.brandSoft : Colors.white,
                radius: 16,
                onTap: () => setState(() => pick = i),
                child: Row(children: [
                  Icon(pick == i ? Icons.radio_button_checked : Icons.radio_button_off,
                      color: pick == i ? C.brand : C.faint),
                  const SizedBox(width: 10),
                  Expanded(child: Text(securityQuestions[i], style: tLabel())),
                ]),
              ),
            ),
          const SizedBox(height: 8),
          Text('Cevabınız', style: tStrong(size: 15)),
          const SizedBox(height: 8),
          TextField(
            controller: answer,
            onChanged: (_) => setState(() {}),
            style: ts(15),
            decoration: const InputDecoration(hintText: 'Cevabı yazın'),
          ),
          const SizedBox(height: 6),
          Text('Büyük-küçük harf fark etmez.', style: tCaption()),
          const SizedBox(height: 22),
          PrimaryButton('Kaydet ve başla',
              color: C.ok, dark: C.okDark, onTap: answer.text.trim().isEmpty ? null : _finish),
        ],
      );
}
