import 'package:flutter/material.dart';

/// Uygulamanın renkleri. Çocuk tarafı sıcak ve canlı, ebeveyn tarafı sade ve düzenli.
class C {
  // zemin ve yazı
  static const bg = Color(0xFFF4F6FB);
  static const surface = Colors.white;
  static const ink = Color(0xFF18213F);
  static const body = Color(0xFF3A4466);
  static const muted = Color(0xFF6B7491);
  static const faint = Color(0xFFA3AAC0);
  static const line = Color(0xFFE3E7F1);
  static const track = Color(0xFFEDF0F7);

  // marka
  static const brand = Color(0xFF3949D8);
  static const brandDark = Color(0xFF2632A6);
  static const brandSoft = Color(0xFFEEF0FF);
  static const navy = Color(0xFF1C2669);
  static const navyMid = Color(0xFF253296);

  // vurgu
  static const sun = Color(0xFFFFC23D);
  static const sunDark = Color(0xFFE0A100);
  static const sunSoft = Color(0xFFFFF4D6);
  static const sunInk = Color(0xFF8A5A00);
  static const sunOnDark = Color(0xFFFFD872);

  // durum
  static const ok = Color(0xFF12A06B);
  static const okDark = Color(0xFF0B7D52);
  static const okSoft = Color(0xFFE3F7EE);
  static const warn = Color(0xFFF5A524);
  static const err = Color(0xFFE5484D);
  static const errDark = Color(0xFFB8333A);
  static const errSoft = Color(0xFFFDECEC);
}

const kFont = 'Poppins';

/// Yazı biçimi. Poppins'in uygulamaya gömülü üç kalınlığı vardır: 400, 500, 700.
TextStyle ts(double size, {FontWeight w = FontWeight.w400, Color color = C.ink, double height = 1.35, double? spacing}) =>
    TextStyle(fontFamily: kFont, fontSize: size, fontWeight: w, color: color, height: height, letterSpacing: spacing);

TextStyle tDisplay({Color color = C.ink}) => ts(26, w: FontWeight.w700, color: color, height: 1.15);
TextStyle tTitle({Color color = C.ink, double size = 19}) => ts(size, w: FontWeight.w700, color: color, height: 1.25);
TextStyle tLabel({Color color = C.ink, double size = 14}) => ts(size, w: FontWeight.w500, color: color);
TextStyle tStrong({Color color = C.ink, double size = 14}) => ts(size, w: FontWeight.w700, color: color);
TextStyle tBody({Color color = C.body, double size = 14}) => ts(size, color: color, height: 1.5);
TextStyle tCaption({Color color = C.muted, double size = 12.5}) => ts(size, color: color, height: 1.45);
TextStyle tOverline({Color color = C.muted}) => ts(11.5, w: FontWeight.w500, color: color, spacing: 0.6);

const kShadow = [BoxShadow(color: Color(0x1218213F), blurRadius: 16, offset: Offset(0, 4))];

const kHeaderGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [C.navy, C.brand],
);

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: C.brand, primary: C.brand, surface: C.surface);
  OutlineInputBorder border(Color c, [double w = 1.5]) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: c, width: w));
  return ThemeData(
    useMaterial3: true,
    fontFamily: kFont,
    colorScheme: scheme,
    scaffoldBackgroundColor: C.bg,
    appBarTheme: const AppBarTheme(backgroundColor: C.bg, foregroundColor: C.ink, elevation: 0, scrolledUnderElevation: 0),
    dividerTheme: const DividerThemeData(color: C.line, thickness: 1, space: 1),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      hintStyle: ts(14, color: C.faint),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: border(C.line),
      enabledBorder: border(C.line),
      focusedBorder: border(C.brand, 2),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: C.brand, textStyle: ts(14, w: FontWeight.w500)),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      titleTextStyle: tTitle(size: 18),
      contentTextStyle: tBody(),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: C.ink,
      contentTextStyle: ts(14, color: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? Colors.white : null),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? C.brand : null),
    ),
  );
}

/// Üç ana bölüm.
class Konu {
  final String key;
  final String title;
  final String subtitle;
  final Color color;
  final Color dark;
  final Color light;
  final IconData icon;
  const Konu(this.key, this.title, this.subtitle, this.color, this.dark, this.light, this.icon);
}

const konular = [
  Konu('sozel', 'Sözel', 'Kelimeler, sayılar ve mantık', Color(0xFFFF7A59), Color(0xFFD9572F), Color(0xFFFFF0EB),
      Icons.chat_bubble_rounded),
  Konu('gorsel', 'Görsel', 'Şekiller, katlama ve döndürme', Color(0xFF16A37F), Color(0xFF0F7F62), Color(0xFFE4F6EF),
      Icons.category_rounded),
  Konu('matris', 'Matris', 'Kuralı bul, kutuyu doldur', Color(0xFF7C5CFF), Color(0xFF5B3FE0), Color(0xFFF1EDFF),
      Icons.grid_view_rounded),
];

Konu konuOf(String key) => konular.firstWhere((k) => k.key == key);

/// Türkçeye uygun büyük harf (i → İ).
String trUpper(String s) => s.replaceAll('i', 'İ').toUpperCase();
