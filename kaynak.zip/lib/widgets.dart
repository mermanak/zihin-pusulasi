import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'data.dart';
import 'theme.dart';

/// Tablette içeriği ortalı ve okunabilir genişlikte tutar.
class Frame extends StatelessWidget {
  final Widget child;
  const Frame({super.key, required this.child});
  @override
  Widget build(BuildContext context) =>
      Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 560), child: child));
}

// ------------------------------------------------------------------ temel yapı taşları
/// Gölgeli beyaz kart.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color color;
  final double radius;
  final VoidCallback? onTap;
  final BoxBorder? border;
  final bool shadow;
  final String? semanticLabel;
  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color = Colors.white,
    this.radius = 20,
    this.onTap,
    this.border,
    this.shadow = true,
    this.semanticLabel,
  });

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    return Semantics(
      button: onTap != null,
      label: semanticLabel,
      child: Container(
        decoration: BoxDecoration(color: color, borderRadius: r, border: border, boxShadow: shadow ? kShadow : null),
        child: Material(
          color: Colors.transparent,
          borderRadius: r,
          child: InkWell(
            borderRadius: r,
            onTap: onTap,
            child: Padding(padding: padding, child: child),
          ),
        ),
      ),
    );
  }
}

/// Ana eylem düğmesi: altında hafif koyu bir kenar olan, dokunulası bir düğme.
class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final Color color;
  final Color dark;
  final Color textColor;
  final IconData? icon;
  final double height;
  const PrimaryButton(this.label,
      {super.key,
      this.onTap,
      this.color = C.brand,
      this.dark = C.brandDark,
      this.textColor = Colors.white,
      this.icon,
      this.height = 54});

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    final bg = enabled ? color : const Color(0xFFDDE1EC);
    final edge = enabled ? dark : const Color(0xFFC9CEDC);
    final fg = enabled ? textColor : C.muted;
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: height,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: edge, offset: const Offset(0, 4))],
          ),
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, color: fg, size: 22), const SizedBox(width: 8)],
            Flexible(
              child: Text(label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: ts(16, w: FontWeight.w700, color: fg, height: 1.2)),
            ),
          ]),
        ),
      ),
    );
  }
}

/// İkincil düğme: beyaz zemin, ince çerçeve.
class SecondaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final Color color;
  final IconData? icon;
  const SecondaryButton(this.label, {super.key, this.onTap, this.color = C.brand, this.icon});

  @override
  Widget build(BuildContext context) {
    final fg = onTap == null ? C.faint : color;
    return Semantics(
      button: true,
      enabled: onTap != null,
      label: label,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Container(
            height: 54,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: C.line, width: 2),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              if (icon != null) ...[Icon(icon, color: fg, size: 20), const SizedBox(width: 8)],
              Flexible(
                child: Text(label,
                    textAlign: TextAlign.center, maxLines: 2, style: ts(15, w: FontWeight.w700, color: fg, height: 1.2)),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Küçük kare simge düğmesi.
class IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final String label;
  final Color bg;
  final Color fg;
  final double size;
  const IconBtn(this.icon,
      {super.key, required this.onTap, required this.label, this.bg = C.bg, this.fg = C.ink, this.size = 42});

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        label: label,
        child: Material(
          color: bg,
          borderRadius: BorderRadius.circular(13),
          child: InkWell(
            borderRadius: BorderRadius.circular(13),
            onTap: onTap,
            child: SizedBox(width: size, height: size, child: Icon(icon, color: fg, size: size * 0.52)),
          ),
        ),
      );
}

/// Küçük etiket.
class Pill extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  final IconData? icon;
  final double size;
  final Color? borderColor;
  const Pill(this.text, {super.key, this.bg = C.brandSoft, this.fg = C.brand, this.icon, this.size = 11.5, this.borderColor});

  @override
  Widget build(BuildContext context) => Container(
        padding: EdgeInsets.symmetric(horizontal: size > 12 ? 12 : 10, vertical: size > 12 ? 6 : 4),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(999),
          border: borderColor == null ? null : Border.all(color: borderColor!, width: 1.2),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: size + 4, color: fg), const SizedBox(width: 5)],
          Text(text, style: ts(size, w: FontWeight.w500, color: fg, height: 1.2, spacing: 0.2)),
        ]),
      );
}

/// "Deneme sürümü" etiketi.
class DemoBadge extends StatelessWidget {
  final bool onDark;
  const DemoBadge({super.key, this.onDark = false});
  @override
  Widget build(BuildContext context) => Semantics(
        label: 'Deneme sürümü',
        child: Pill('DENEME SÜRÜMÜ',
            icon: Icons.auto_awesome_rounded,
            bg: onDark ? C.sun.withAlpha(46) : C.sunSoft,
            fg: onDark ? C.sunOnDark : C.sunInk,
            borderColor: onDark ? C.sun.withAlpha(120) : null),
      );
}

/// Yıldız sayacı.
class StarPill extends StatelessWidget {
  final int count;
  const StarPill(this.count, {super.key});
  @override
  Widget build(BuildContext context) => Semantics(
        label: '$count yıldız',
        child: Container(
          height: 36,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.star_rounded, color: C.sun, size: 22),
            const SizedBox(width: 4),
            Text('$count', style: tStrong(size: 15)),
          ]),
        ),
      );
}

/// İnce ilerleme çubuğu.
class ProgressLine extends StatelessWidget {
  final double value;
  final Color color;
  final Color track;
  final double height;
  const ProgressLine(this.value, {super.key, required this.color, this.track = C.track, this.height = 8});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(height),
        child: SizedBox(
          height: height,
          child: Stack(fit: StackFit.expand, children: [
            ColoredBox(color: track),
            FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: value.clamp(0.0, 1.0).toDouble(),
              child: DecoratedBox(
                  decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(height))),
            ),
          ]),
        ),
      );
}

/// Halka biçiminde ilerleme göstergesi.
class Ring extends StatelessWidget {
  final double value;
  final double size;
  final double stroke;
  final Color color;
  final Color track;
  final Widget? child;
  const Ring(this.value,
      {super.key, this.size = 56, this.stroke = 6, this.color = C.sun, this.track = C.track, this.child});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _RingPainter(value.clamp(0.0, 1.0).toDouble(), stroke, color, track),
          child: Center(child: child),
        ),
      );
}

class _RingPainter extends CustomPainter {
  final double value;
  final double stroke;
  final Color color;
  final Color track;
  _RingPainter(this.value, this.stroke, this.color, this.track);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(stroke / 2, stroke / 2, size.width - stroke, size.height - stroke);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, 0, math.pi * 2, false, p..color = track);
    if (value > 0) canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * value, false, p..color = color);
  }

  @override
  bool shouldRepaint(covariant _RingPainter o) => o.value != value || o.color != color || o.track != track;
}

/// Bölüm başlığı.
class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(children: [
          Expanded(child: Text(text, style: tTitle(size: 17))),
          if (trailing != null) trailing!,
        ]),
      );
}

/// Bilgi kutusu.
class InfoNote extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color bg;
  final Color fg;
  const InfoNote(this.text,
      {super.key, this.icon = Icons.info_outline_rounded, this.bg = C.brandSoft, this.fg = C.brandDark});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: fg, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: tCaption(color: fg))),
        ]),
      );
}

/// Üstte koyu renk geçişli başlık alanı.
class GradientHeader extends StatelessWidget {
  final Widget child;
  final Gradient gradient;
  final EdgeInsetsGeometry padding;
  final double radius;
  const GradientHeader(
      {super.key,
      required this.child,
      this.gradient = kHeaderGradient,
      this.padding = const EdgeInsets.fromLTRB(20, 12, 20, 20),
      this.radius = 30});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(radius)),
        ),
        child: SafeArea(bottom: false, child: Frame(child: Padding(padding: padding, child: child))),
      );
}

LinearGradient konuGradient(Konu k) =>
    LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [k.dark, k.color]);

// ------------------------------------------------------------------ Bilge Baykuş
enum OwlMood { normal, happy, think }

class Owl extends StatelessWidget {
  final double size;
  final OwlMood mood;
  const Owl({super.key, this.size = 96, this.mood = OwlMood.normal});
  @override
  Widget build(BuildContext context) => ExcludeSemantics(
      child: SizedBox(width: size, height: size, child: CustomPaint(painter: _OwlPainter(mood))));
}

class _OwlPainter extends CustomPainter {
  final OwlMood mood;
  _OwlPainter(this.mood);

  Path _tri(double x1, double y1, double x2, double y2, double x3, double y3) => Path()
    ..moveTo(x1, y1)
    ..lineTo(x2, y2)
    ..lineTo(x3, y3)
    ..close();

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 120;
    canvas.save();
    canvas.scale(s, s);
    final dark = Paint()..color = const Color(0xFFE07A1F);
    canvas.drawPath(_tri(30, 34, 36, 12, 50, 30), dark);
    canvas.drawPath(_tri(90, 34, 84, 12, 70, 30), dark);
    if (mood == OwlMood.happy) {
      canvas.drawPath(
          Path()
            ..moveTo(22, 66)
            ..quadraticBezierTo(4, 50, 12, 34)
            ..quadraticBezierTo(22, 50, 34, 60)
            ..close(),
          dark);
      canvas.drawPath(
          Path()
            ..moveTo(98, 66)
            ..quadraticBezierTo(116, 50, 108, 34)
            ..quadraticBezierTo(98, 50, 86, 60)
            ..close(),
          dark);
    } else {
      canvas.drawPath(
          Path()
            ..moveTo(20, 72)
            ..quadraticBezierTo(8, 94, 28, 104)
            ..quadraticBezierTo(24, 86, 32, 76)
            ..close(),
          dark);
      canvas.drawPath(
          Path()
            ..moveTo(100, 72)
            ..quadraticBezierTo(112, 94, 92, 104)
            ..quadraticBezierTo(96, 86, 88, 76)
            ..close(),
          dark);
    }
    canvas.drawOval(Rect.fromCenter(center: const Offset(60, 68), width: 80, height: 88),
        Paint()..color = const Color(0xFFFF9F43));
    canvas.drawOval(Rect.fromCenter(center: const Offset(60, 84), width: 48, height: 50),
        Paint()..color = const Color(0xFFFFE3B8));
    final ink = Paint()..color = C.ink;
    if (mood == OwlMood.happy) {
      final st = Paint()
        ..color = C.ink
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round;
      canvas.drawPath(Path()..moveTo(32, 54)..quadraticBezierTo(44, 42, 56, 54), st);
      canvas.drawPath(Path()..moveTo(64, 54)..quadraticBezierTo(76, 42, 88, 54), st);
    } else {
      final w = Paint()..color = Colors.white;
      canvas.drawCircle(const Offset(44, 54), 16, w);
      canvas.drawCircle(const Offset(76, 54), 16, w);
      final think = mood == OwlMood.think;
      final p1 = think ? const Offset(48, 49) : const Offset(47, 56);
      final p2 = think ? const Offset(80, 49) : const Offset(73, 56);
      canvas.drawCircle(p1, 7.5, ink);
      canvas.drawCircle(p2, 7.5, ink);
      canvas.drawCircle(p1 + const Offset(2.5, -3), 2.4, w);
      canvas.drawCircle(p2 + const Offset(2.5, -3), 2.4, w);
    }
    final beak = _tri(54, 68, 66, 68, 60, 77);
    canvas.drawPath(beak, Paint()..color = C.sun);
    canvas.drawPath(
        beak,
        Paint()
          ..color = const Color(0xFFC98F00)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..strokeJoin = StrokeJoin.round);
    final feet = Paint()
      ..color = const Color(0xFFC98F00)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(
        Path()
          ..moveTo(48, 112)
          ..lineTo(52, 106)
          ..lineTo(56, 112)
          ..moveTo(64, 112)
          ..lineTo(68, 106)
          ..lineTo(72, 112),
        feet);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _OwlPainter oldDelegate) => oldDelegate.mood != mood;
}

/// Konuşma balonu.
class Bubble extends StatelessWidget {
  final String text;
  final String? title;
  const Bubble(this.text, {super.key, this.title});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(18),
            topRight: Radius.circular(18),
            bottomRight: Radius.circular(18),
            bottomLeft: Radius.circular(6),
          ),
          boxShadow: kShadow,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (title != null) Text(title!, style: tTitle()),
            Text(text, style: title != null ? tCaption(size: 13.5) : tLabel(size: 14.5)),
          ],
        ),
      );
}

// ------------------------------------------------------------------ şifre tuş takımı
class PinDots extends StatelessWidget {
  final int filled;
  const PinDots(this.filled, {super.key});
  @override
  Widget build(BuildContext context) => Semantics(
        label: '$filled hane girildi',
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            4,
            (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              margin: const EdgeInsets.symmetric(horizontal: 9),
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: i < filled ? C.brand : Colors.white,
                border: Border.all(color: i < filled ? C.brand : const Color(0xFFC9CFE3), width: 2.5),
              ),
            ),
          ),
        ),
      );
}

class PinPad extends StatelessWidget {
  final void Function(String) onDigit;
  final VoidCallback onDelete;
  final String extraLabel;
  final VoidCallback? onExtra;
  const PinPad({super.key, required this.onDigit, required this.onDelete, this.extraLabel = '', this.onExtra});

  Widget _key(String label, VoidCallback? onTap, {IconData? icon}) => Expanded(
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: label.isEmpty && icon == null
              ? const SizedBox(height: 60)
              : Semantics(
                  button: true,
                  label: icon != null ? 'Sil' : label,
                  child: Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: onTap,
                      child: Container(
                        height: 60,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: C.line, width: 1.5),
                        ),
                        child: icon != null
                            ? Icon(icon, color: C.ink)
                            : Text(label, style: ts(label.length > 2 ? 14 : 24, w: FontWeight.w500)),
                      ),
                    ),
                  ),
                ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final rows = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
    ];
    return Column(children: [
      for (final r in rows) Row(children: [for (final k in r) _key(k, () => onDigit(k))]),
      Row(children: [
        _key(extraLabel, onExtra),
        _key('0', () => onDigit('0')),
        _key('', onDelete, icon: Icons.backspace_outlined),
      ]),
    ]);
  }
}

// ------------------------------------------------------------------ soru gövdesi
enum TileState { normal, selected, correct, wrong, dim }

class OptionTile extends StatelessWidget {
  final Opt opt;
  final TileState state;
  final Konu konu;
  final VoidCallback? onTap;
  const OptionTile({super.key, required this.opt, required this.state, required this.konu, this.onTap});

  @override
  Widget build(BuildContext context) {
    var bg = Colors.white;
    var border = C.line;
    double bw = 2;
    var badgeBg = C.track;
    var badgeFg = C.muted;
    List<BoxShadow>? shadow;
    switch (state) {
      case TileState.selected:
        bg = konu.light;
        border = konu.color;
        bw = 3;
        badgeBg = konu.color;
        badgeFg = Colors.white;
        shadow = [BoxShadow(color: konu.color.withAlpha(60), blurRadius: 12, offset: const Offset(0, 4))];
        break;
      case TileState.correct:
        bg = C.okSoft;
        border = C.ok;
        bw = 3;
        badgeBg = C.ok;
        badgeFg = Colors.white;
        break;
      case TileState.wrong:
        bg = C.errSoft;
        border = C.err;
        bw = 3;
        badgeBg = C.err;
        badgeFg = Colors.white;
        break;
      default:
        break;
    }
    final isImage = opt.image != null;
    Widget badge(double d) => Container(
          width: d,
          height: d,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: badgeBg, shape: BoxShape.circle),
          child: state == TileState.correct
              ? Icon(Icons.check_rounded, size: d * 0.7, color: Colors.white)
              : state == TileState.wrong
                  ? Icon(Icons.close_rounded, size: d * 0.7, color: Colors.white)
                  : Text(opt.id, style: ts(d * 0.5, w: FontWeight.w700, color: badgeFg, height: 1)),
        );
    final Widget content = isImage
        ? Stack(children: [
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: Image.asset('assets/${opt.image}', fit: BoxFit.contain),
              ),
            ),
            Positioned(left: 0, top: 0, child: badge(24)),
          ])
        : Row(children: [
            badge(32),
            const SizedBox(width: 12),
            Expanded(child: Text(opt.text ?? '', style: ts(16, w: FontWeight.w500, height: 1.3))),
          ]);
    return Opacity(
      opacity: state == TileState.dim ? 0.4 : 1,
      child: Semantics(
        button: onTap != null,
        selected: state == TileState.selected,
        label: 'Şık ${opt.id}${isImage ? '' : ': ${opt.text}'}',
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: border, width: bw),
            boxShadow: shadow,
          ),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: onTap,
              child: Padding(
                padding: EdgeInsets.all(isImage ? 6 : 12),
                child: content,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Sorunun ölçtüğü beceriyi gösteren küçük etiket.
class SkillChip extends StatelessWidget {
  final String text;
  final Color color;
  const SkillChip(this.text, {super.key, this.color = C.brand});

  @override
  Widget build(BuildContext context) => Semantics(
        label: 'Beceri: $text',
        child: Container(
          padding: const EdgeInsets.fromLTRB(8, 4, 12, 4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: color.withAlpha(70), width: 1.5),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.psychology_rounded, size: 17, color: color),
            const SizedBox(width: 5),
            Text(text, style: ts(12, w: FontWeight.w500, color: color, height: 1.2)),
          ]),
        ),
      );
}

class QuestionBody extends StatelessWidget {
  final Question q;
  final Konu konu;
  final TileState Function(Opt) stateOf;
  final void Function(Opt)? onTap;
  final double imageHeight;
  const QuestionBody(
      {super.key, required this.q, required this.konu, required this.stateOf, this.onTap, this.imageHeight = 280});

  @override
  Widget build(BuildContext context) {
    final children = <Widget>[];
    if (q.beceri != null) {
      children.add(Align(alignment: Alignment.centerLeft, child: SkillChip(q.beceri!, color: konu.dark)));
      children.add(const SizedBox(height: 12));
    }
    if (q.image == null && !q.hasImageOptions) {
      final long = q.stem.length > 140;
      children.add(AppCard(
        padding: EdgeInsets.symmetric(horizontal: 18, vertical: long ? 18 : 22),
        child: SizedBox(
          width: double.infinity,
          child: Text(q.stem,
              textAlign: long ? TextAlign.left : TextAlign.center,
              style: long ? ts(16, height: 1.6, color: C.ink) : ts(19, w: FontWeight.w700, height: 1.4)),
        ),
      ));
    } else {
      children.add(Text(q.stem, style: ts(17, w: FontWeight.w700, height: 1.4)));
      if (q.image != null) {
        children.add(const SizedBox(height: 12));
        children.add(AppCard(
          padding: const EdgeInsets.all(12),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: imageHeight),
            child: Center(child: Image.asset('assets/${q.image}', fit: BoxFit.contain)),
          ),
        ));
      }
    }
    children.add(const SizedBox(height: 16));

    Widget tile(int i) {
      final o = q.options[i];
      return OptionTile(
        opt: o,
        state: stateOf(o),
        konu: konu,
        onTap: onTap == null ? null : () => onTap!(o),
      );
    }

    if (q.hasImageOptions) {
      children.add(LayoutBuilder(builder: (context, box) {
        final n = q.options.length;
        final wide = box.maxWidth >= 480;
        final cols = n <= 4 ? (wide ? 4 : 2) : 3;
        final ratio = n <= 4 && !wide ? 1.3 : 0.95;
        return GridView.count(
          crossAxisCount: cols,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: ratio,
          children: [for (var i = 0; i < n; i++) tile(i)],
        );
      }));
    } else {
      final long = q.options.any((o) => (o.text ?? '').length > 14);
      if (long) {
        for (var i = 0; i < q.options.length; i++) {
          children.add(Padding(padding: const EdgeInsets.only(bottom: 10), child: tile(i)));
        }
      } else {
        for (var i = 0; i < q.options.length; i += 2) {
          children.add(Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(children: [
              Expanded(child: tile(i)),
              const SizedBox(width: 10),
              Expanded(child: i + 1 < q.options.length ? tile(i + 1) : const SizedBox()),
            ]),
          ));
        }
      }
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }
}

/// Soru ekranının üst çubuğu: kapat, bölümlü ilerleme, sayaç, sesli okuma.
class QuestionHeader extends StatelessWidget {
  final Konu konu;
  final int total;
  final int index;
  final int filled;
  final String label;
  final VoidCallback onClose;
  final VoidCallback? onListen;
  const QuestionHeader({
    super.key,
    required this.konu,
    required this.total,
    required this.index,
    required this.filled,
    required this.label,
    required this.onClose,
    this.onListen,
  });

  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(bottom: BorderSide(color: C.line)),
        ),
        padding: EdgeInsets.fromLTRB(14, MediaQuery.of(context).padding.top + 10, 14, 12),
        child: Frame(
          child: Column(children: [
            Row(children: [
              IconBtn(Icons.close_rounded, onTap: onClose, label: 'Çık'),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: tOverline(color: konu.dark)),
                  const SizedBox(height: 5),
                  Row(children: [
                    for (var k = 0; k < total; k++) ...[
                      Expanded(
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          height: 8,
                          decoration: BoxDecoration(
                            color: k < filled
                                ? konu.color
                                : (k == index ? konu.color.withAlpha(90) : C.track),
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                      ),
                      if (k < total - 1) const SizedBox(width: 4),
                    ],
                  ]),
                ]),
              ),
              const SizedBox(width: 12),
              Text('${index + 1}/$total', style: tStrong(size: 14)),
              if (onListen != null) ...[
                const SizedBox(width: 10),
                IconBtn(Icons.volume_up_rounded,
                    onTap: onListen, label: 'Soruyu sesli dinle', bg: konu.light, fg: konu.dark),
              ],
            ]),
          ]),
        ),
      );
}
